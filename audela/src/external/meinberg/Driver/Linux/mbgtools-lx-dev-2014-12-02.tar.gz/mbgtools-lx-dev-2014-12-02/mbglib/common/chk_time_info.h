
/**************************************************************************
 *
 *  $Id: chk_time_info.h 1.2 2013/03/04 16:02:31 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Definitions and prototypes for chk_time_info.c.
 *
 * -----------------------------------------------------------------------
 *  $Log: chk_time_info.h $
 *  Revision 1.2  2013/03/04 16:02:31  martin
 *  Updated function prototypes.
 *  Revision 1.1  2012/05/29 09:52:27  martin
 *  Initial revision.
 *
 **************************************************************************/

#ifndef _CHK_TIME_INFO_H
#define _CHK_TIME_INFO_H


/* Other headers to be included */

#include <mbgdevio.h>


#ifdef _CHK_TIME_INFO
 #define _ext
 #define _DO_INIT
#else
 #define _ext extern
#endif


/* Start of header body */

#if 0 && defined( _USE_PACK )  // use default alignment
  #pragma pack( 1 )      // set byte alignment
  #define _USING_BYTE_ALIGNMENT
#endif

#ifdef __cplusplus
extern "C" {
#endif


#if !defined( MAX_FILTER_ENTRIES )
  #define MAX_FILTER_ENTRIES    32
#endif


typedef struct
{
  MBG_PC_CYCLES cyc[MAX_FILTER_ENTRIES];
  MBG_PC_CYCLES sum;
  int entries;
  int index;
} FILTER;


typedef struct
{
  MBG_TIME_INFO_HRT hrti;

  MBG_PC_CYCLES ltcy_cyc;
  MBG_PC_CYCLES exec_cyc;
  MBG_PC_CYCLES exec_cyc_limit;

  double ltcy_sec;
  double exec_sec;
  double exec_sec_limit;

  double d_sys;
  double d_ref;
  double d_ref_comp;

} MBG_CHK_TIME_INFO;



/* function prototypes: */

/* ----- function prototypes begin ----- */

/* This section was generated automatically */
/* by MAKEHDR, do not remove the comments. */

 int mbg_chk_time_info( MBG_DEV_HANDLE dh, MBG_CHK_TIME_INFO *p, FILTER *p_filter, int fast_ts_only ) ;
 int snprint_chk_time_info( char *s, size_t max_len, const MBG_CHK_TIME_INFO *p, const PCPS_DEV *p_dev, int frac_digits, int print_raw ) ;

/* ----- function prototypes end ----- */

#ifdef __cplusplus
}
#endif


#if defined( _USING_BYTE_ALIGNMENT )
  #pragma pack()      // set default alignment
  #undef _USING_BYTE_ALIGNMENT
#endif

/* End of header body */


#undef _ext
#undef _DO_INIT

#endif  /* _CHK_TIME_INFO_H */

