
/**************************************************************************
 *
 *  $Id: rsrc_lx.h 1.4 2008/12/05 12:02:28 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Definitions and prototypes for rsrc_lx.c.
 *
 * -----------------------------------------------------------------------
 *  $Log: rsrc_lx.h $
 *  Revision 1.4  2008/12/05 12:02:28  martin
 *  Updated function prototypes.
 *  Revision 1.3  2006/07/07 12:14:25  martin
 *  Include mbg_lx.h to have modversions, if required.
 *  Revision 1.2  2001/03/05 16:27:57  MARTIN
 *  New macros to make function parameters match.
 *  Removed obsolete function prototypes.
 *
 **************************************************************************/

#ifndef _RSRC_LX_H
#define _RSRC_LX_H


/* Other headers to be included */

#include <mbg_lx.h>
#include <rsrc.h>
#include <words.h>

#ifdef _RSRC_LX
 #define _ext
#else
 #define _ext extern
#endif


/* Start of header body */

/* End of header body */

#undef _ext


/* function prototypes: */

#define _rsrc_alloc_ports( _ph, _pb, _n, _w ) \
  rsrc_alloc_ports( _pb, _n, _w )

#define _rsrc_dealloc_ports( _ph, _pb, _n ) \
  rsrc_dealloc_ports( _pb, _n )


#ifdef __cplusplus
extern "C" {
#endif

/* ----- function prototypes begin ----- */

/* This section was generated automatically */
/* by MAKEHDR, do not remove the comments. */

 int rsrc_alloc_ports( ulong port, ulong n, ushort decode_width ) ;
 void rsrc_dealloc_ports( ulong port, ulong n ) ;

/* ----- function prototypes end ----- */

#ifdef __cplusplus
}
#endif


#endif  /* _RSRC_LX_H */
