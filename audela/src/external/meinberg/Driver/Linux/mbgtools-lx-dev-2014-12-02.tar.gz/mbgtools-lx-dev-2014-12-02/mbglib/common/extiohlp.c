
/**************************************************************************
 *
 *  $Id: extiohlp.c 1.3 2013/02/01 15:49:59 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Device configuration helper functions. This is an extension to
 *    mbgextio.c providing useful functions to simplify reading/writing
 *    complex device configuration structure sets.
 *
 *  Warning:
 *    These functions should not be implemented in a DLL / shared library
 *    since the parameter sizes might vary with different versions
 *    of the API calls, which which would make different versions of
 *    precompiled libraries incompatible to each other.
 *
 * -----------------------------------------------------------------------
 *  $Log: extiohlp.c $
 *  Revision 1.3  2013/02/01 15:49:59  martin
 *  Updated doxygen comments.
 *  Cleanup.
 *  Revision 1.2  2012/03/09 08:32:58Z  martin
 *  Cleanup.
 *  Revision 1.1  2011/09/21 15:59:59  martin
 *  Initial revision.
 *
 **************************************************************************/

#define _EXTIOHLP
  #include <extiohlp.h>
#undef _EXTIOHLP



/*HDR*/
/**
 * @brief Read all serial port settings and supported configuration parameters
 *
 * @note The function mbgextio_setup_receiver_info() must have been called before,
 * and the returned ::RECEIVER_INFO has to be passed to this function.
 *
 * The complementary function mbgextio_save_serial_settings() should
 * be used to write a modified port configuration back to the device.
 *
 * @param pmctl   Pointer to a valid message control structure
 * @param *p_cfg  Pointer to a ::RECEIVER_PORT_CFG structure to be set up
 * @param *p_ri   Pointer to a valid ::RECEIVER_INFO structure
 *
 * @return  0 on success, < 0 on error
 *
 * @see mbgextio_save_serial_settings
 * @see mbgextio_get_receiver_info
 */
int mbgextio_get_serial_settings( MBG_MSG_CTL *pmctl, RECEIVER_PORT_CFG *p_cfg,
                                  const RECEIVER_INFO *p_ri )
{
  int rc = 0;

  memset( p_cfg, 0, sizeof( *p_cfg ) );

  if ( p_ri->model_code != GPS_MODEL_UNKNOWN )
  {
    rc = mbgextio_get_all_port_info( pmctl, p_cfg->pii, p_ri );

    if ( !( rc < 0 ) )
      rc = mbgextio_get_all_str_type_info( pmctl, p_cfg->stii, p_ri );
  }
  else
  {
  #if 0 //##++++++++++++++++++
    uint16_t i;

    rc = mbgextio_get_port_parm( pmctl, &pcfg->tmp_pp );

    if ( !( rc < 0 ) )
    {
      for ( i = 0; i < p_ri->n_com_ports; i++ )
      {
        PORT_INFO_IDX *p_pii = &pcfg->pii[i];
        PORT_INFO *p_pi = &p_pii->port_info;

        p_pii->idx = i;
        port_settings_from_port_parm( &p_pi->port_settings,
                                      i, &pcfg->tmp_pp, 1 );

        p_pi->supp_baud_rates = DEFAULT_GPS_BAUD_RATES_C166;
        p_pi->supp_framings = DEFAULT_GPS_FRAMINGS_C166;
        p_pi->supp_str_types = DEFAULT_SUPP_STR_TYPES_GPS;
      }

      for ( i = 0; i < p_ri->n_str_type; i++ )
      {
        STR_TYPE_INFO_IDX *stip = &pcfg->stii[i];
        stip->idx = i;
        stip->str_type_info = default_str_type_info[i];
      }
    }
  #endif

    rc = -10;
  }

  return rc;

}  // mbgextio_get_serial_settings



/*HDR*/
/**
 * @brief Send the configuration settings for a single serial port to a device
 *
 * @note The function mbgextio_setup_receiver_info() must have been called before,
 * and the returned ::RECEIVER_INFO has to be passed to this function as well as
 * to mbgextio_get_serial_settings() which should have been called befor to read
 * the current settings and supported features for each port.
 *
 * @param pmctl     Valid pointer to a message control structure
 * @param pcfg      Pointer to a ::RECEIVER_PORT_CFG structure
 * @param port_idx  Index of the serial port to be saved
 *
 * @return ::MBG_SUCCESS or error code returned by device I/O control function.
 *
 * @see mbgextio_get_serial_settings
 * @see mbgextio_get_receiver_info
 */
int mbgextio_save_serial_settings( MBG_MSG_CTL *pmctl, const RECEIVER_PORT_CFG *pcfg, uint16_t port_idx )
{
  int rc;

  rc = mbgextio_set_port_settings_idx( pmctl, &pcfg->pii[port_idx].port_info.port_settings, port_idx );

  return rc;  //##++ MBG_SUCCESS or < 0 on error

}  // mbgextio_save_serial_settings



