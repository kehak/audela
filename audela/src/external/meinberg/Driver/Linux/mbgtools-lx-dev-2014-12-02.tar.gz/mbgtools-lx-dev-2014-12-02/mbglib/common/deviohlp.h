
/**************************************************************************
 *
 *  $Id: deviohlp.h 1.2 2012/10/15 13:51:18 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Definitions and prototypes for deviohlp.c.
 *
 * -----------------------------------------------------------------------
 *  $Log: deviohlp.h $
 *  Revision 1.2  2012/10/15 13:51:18  martin
 *  Include cfg_hlp.h.
 *  Added structure ALL_PTP_CFG_INFO.
 *  Updated function prototypes.
 *  Revision 1.1  2011/08/03 15:36:44Z  martin
 *  Initial revision with functions moved here from mbgdevio.
 *
 **************************************************************************/

#ifndef _DEVIOHLP_H
#define _DEVIOHLP_H


/* Other headers to be included */

#include <mbgdevio.h>
#include <cfg_hlp.h>


#ifdef _DEVIOHLP
 #define _ext
 #define _DO_INIT
#else
 #define _ext extern
#endif


/* Start of header body */

#ifdef __cplusplus
extern "C" {
#endif


typedef struct
{
  PTP_CFG_INFO ptp_cfg_info;
  PTP_UC_MASTER_CFG_LIMITS ptp_uc_master_cfg_limits;
  ALL_PTP_UC_MASTER_INFO_IDX all_ptp_uc_master_info_idx;

} ALL_PTP_CFG_INFO;



/* function prototypes: */

/* ----- function prototypes begin ----- */

/* This section was generated automatically */
/* by MAKEHDR, do not remove the comments. */

 /**
    Read all serial port settings and supported configuration parameters.

    The functions mbg_get_device_info() and mbg_setup_receiver_info()
    must have been called before, and the returned ::PCPS_DEV and
    ::RECEIVER_INFO structures must be passed to this function.

    The complementary function mbg_save_serial_settings() should be used
    to write the modified serial port configuration back to the board.

    @param dh    Valid handle to a Meinberg device.
    @param *pdev Pointer to a ::PCPS_DEV structure.
    @param *pcfg Pointer to a ::RECEIVER_PORT_CFG structure to be filled up.
    @param *p_ri Pointer to a ::RECEIVER_INFO structure.

    @return ::MBG_SUCCESS or error code returned by device I/O control function.

    @see mbg_get_device_info()
    @see mbg_setup_receiver_info()
    @see mbg_save_serial_settings()
*/
 int mbg_get_serial_settings( MBG_DEV_HANDLE dh, const PCPS_DEV *pdev, RECEIVER_PORT_CFG *pcfg, const RECEIVER_INFO *p_ri ) ;

 /**
    Write the configuration settings for a single serial port to the board.

    Modifications to the serial port configuration should be made only
    after mbg_get_serial_settings() had been called to read all serial port
    settings and supported configuration parameters.
    This function has finally to be called once for every serial port
    the configuration of which has been modified.

    As also required by mbg_get_serial_settings(), the functions
    mbg_get_device_info() and mbg_setup_receiver_info() must have been
    called before, and the returned ::PCPS_DEV and ::RECEIVER_INFO structures
    must be passed to this function.

    @param dh       Valid handle to a Meinberg device
    @param *pdev    Pointer to a ::PCPS_DEV structure
    @param *pcfg    Pointer to a ::RECEIVER_PORT_CFG structure
    @param port_num Index of the ::serial port to be saved

    @return ::MBG_SUCCESS or error code returned by device I/O control function.

    @see mbg_get_serial_settings()
    @see mbg_get_device_info()
    @see mbg_setup_receiver_info()
*/
 int mbg_save_serial_settings( MBG_DEV_HANDLE dh, const PCPS_DEV *pdev, RECEIVER_PORT_CFG *pcfg, int port_num ) ;

 /**
    Read all PTP settings and supported configuration parameters.

    The complementary function mbg_save_all_ptp_cfg_info() should
    be used to write the modified configuration back to the device.

    @param dh    Valid handle to a Meinberg device.
    @param *p    Pointer to a ::ALL_PTP_CFG_INFO structure.

    @return ::MBG_SUCCESS or error code returned by device I/O control function.

    @see mbg_save_all_ptp_cfg_info()
    @see mbg_get_ptp_cfg_info()
    @see mbg_get_ptp_uc_master_cfg_limits()
    @see mbg_get_all_ptp_uc_master_info()
    @see mbg_dev_has_ptp()
    @see mbg_dev_has_ptp_unicast()
*/
 int mbg_get_all_ptp_cfg_info( MBG_DEV_HANDLE dh, ALL_PTP_CFG_INFO *p ) ;

 /**
    Write all PTP settings and supported configuration parameters
    to a device.

    The complementary function mbg_get_all_ptp_cfg_info() should
    have been used to read the original PTP settings and supported
    configuration parameters.

    @param dh    Valid handle to a Meinberg device.
    @param *p    Pointer to a ::ALL_PTP_CFG_INFO structure.

    @return ::MBG_SUCCESS or error code returned by device I/O control function.

    @see mbg_get_all_ptp_cfg_info()
    @see mbg_set_ptp_cfg_settings()
    @see mbg_set_ptp_uc_master_settings_idx()
    @see mbg_dev_has_ptp()
    @see mbg_dev_has_ptp_unicast()
*/
 int mbg_save_all_ptp_cfg_info( MBG_DEV_HANDLE dh, const ALL_PTP_CFG_INFO *p ) ;


/* ----- function prototypes end ----- */

#ifdef __cplusplus
}
#endif


/* End of header body */

#undef _ext
#undef _DO_INIT

#endif  /* _DEVIOHLP_H */
