
/**************************************************************************
 *
 *  $Id: lan_util.h 1.4 2013/02/19 15:15:53 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Definitions and prototypes for lan_util.c.
 *
 * -----------------------------------------------------------------------
 *  $Log: lan_util.h $
 *  Revision 1.4  2013/02/19 15:15:53  martin
 *  Added some inline functions.
 *  Redefined return codes as named enum.
 *  Updated function prototypes.
 *  Revision 1.3  2012/10/02 18:24:29  martin
 *  Added some macros to simpliy conversion to string.
 *  Revision 1.2  2012/03/09 08:51:44  martin
 *  Updated function prototypes.
 *  Revision 1.1  2011/03/04 10:01:32  martin
 *  Initial revision.
 *
 **************************************************************************/

#ifndef _LAN_UTIL_H
#define _LAN_UTIL_H


/* Other headers to be included */

#include <mbg_tgt.h>
#include <gpsdefs.h>

#include <stdlib.h>

#if defined( MBG_TGT_UNIX )
  #include <sys/types.h>
  #include <sys/socket.h>
  #include <net/if.h>
#else
  // A dummy declaration to prevent from warnings due to usage
  // of this type with function prototypes.
  struct ifreq
  {
    int dummy;
  };
#endif


#if defined( IFHWADDRLEN )  // usually defined in net/if.h
  #if ( IFHWADDRLEN != 6 )
    #error Warning: IFHWADDRLEN is not 6!
  #endif
#endif



#ifdef _LAN_UTIL
 #define _ext
 #define _DO_INIT
#else
 #define _ext extern
#endif


/* Start of header body */

#if defined( _USE_PACK )
  #pragma pack( 1 )      // set byte alignment
  #define _USING_BYTE_ALIGNMENT
#endif

#ifdef __cplusplus
extern "C" {
#endif


#if !defined( MAC_SEP_CHAR )
  #define MAC_SEP_CHAR      ':'   // character used to separate octets of a MAC ID
#endif

#if !defined( MAC_SEP_CHAR_ALT )
  #define MAC_SEP_CHAR_ALT  '-'   // alternate character
#endif


/**
 * @brief Return codes for the LAN utility functions
 */
enum MBG_LU_CODES
{
  MBG_LU_SUCCESS       =  0,  ///< success
  MBG_LU_ERR_NSUPP     = -1,  ///< function not supported
  MBG_LU_ERR_PORT_NAME = -2,  ///< port name exceeds max length
  MBG_LU_ERR_SOCKET    = -3,  ///< failed to open socket
  MBG_LU_ERR_IOCTL     = -4,  ///< IOCTL call failed
  MBG_LU_ERR_NOT_SET   = -5,  ///< octets are all 0
  MBG_LU_ERR_BUFF_SZ   = -6,  ///< buffer size too small
  MBG_LU_ERR_FMT       = -7,  ///< parameter format not correct
  MBG_LU_ERR_RANGE     = -8   ///< range for some parameter exceeded
};


#define MAX_IP4_BITS  ( 8 * sizeof( IP4_ADDR ) )

#define IP4_MSB_MASK  ( 1UL << ( MAX_IP4_BITS - 1 ) )

#define MIN_IP4_CIDR_NETMASK_BITS  0
#define MAX_IP4_CIDR_NETMASK_BITS  MAX_IP4_BITS



/**
 * @brief Compute an IP4 net mask according to the number of CIDR netmask bits
 *
 * E.g. the 24 bits mentioned in "172.16.3.250/24" result in 0xFFFFFF00,
 * corresponding to 255.255.255.0 in dotted quad notation.
 *
 * @param netmask_bits  Number of netmask bits from CIDR notation
 *
 * @return  The IP4 net mask
 *
 * @see get_ip4_net_mask_bits()
 */
static __mbg_inline
IP4_ADDR ip4_net_mask_from_cidr( int netmask_bits )
{
  return (IP4_ADDR) ~( ( 1UL << ( MAX_IP4_BITS - netmask_bits ) ) - 1 );

}  // ip4_net_mask_from_cidr



/**
 * @brief Determine the broadcast address for an IP4 address plus net mask
 *
 * E.g. IP 0xAC1003FA, net mask 0xFFFFFF00 yields broadcast addr 0xAC1003FF.
 * In dotted quad notation, IP 172.16.3.250 with net mask 255.255.255.0
 * result in broadcast address 172.16.3.255.
 *
 * @param p_addr  The full IP4 address
 * @param p_mask  The IP4 net mask
 *
 * @return  The determined IP4 broadcast address
 */
static __mbg_inline
IP4_ADDR ip4_broad_addr_from_addr( const IP4_ADDR *p_addr, const IP4_ADDR *p_mask )
{
  return *p_addr | ~(*p_mask);

}  // ip4_broad_addr_from_addr



/**
 * @brief Determine the network part of an IP4 address based on the net mask
 *
 * E.g. IP 0xAC1003FA, net mask 0xFFFFFF00 yields network part 0xAC100300.
 * In dotted quad notation, IP 172.16.3.250 with net mask 255.255.255.0
 * results in network part 172.16.3.0.
 *
 * @param p_addr  The full IP4 address
 * @param p_mask  The IP4 net mask
 *
 * @return  The network part of the IP4 address
 */
static __mbg_inline
IP4_ADDR ip4_net_part_from_addr( const IP4_ADDR *p_addr, const IP4_ADDR *p_mask )
{
  return *p_addr & *p_mask;

}  // ip4_net_part_from_addr



/**
 * @brief Check if two IP4 addresses have the same network part.
 *
 * @param p_addr1  The first IP4 address to check
 * @param p_addr2  The second IP4 address to check
 * @param p_mask   The IP4 net mask
 *
 * @return  true, if the network parts are matching
 */
static __mbg_inline
int ip4_net_part_matches( const IP4_ADDR *p_addr1, const IP4_ADDR *p_addr2,
                           const IP4_ADDR *p_mask )
{
  return ip4_net_part_from_addr( p_addr1, p_mask )
      == ip4_net_part_from_addr( p_addr2, p_mask );

}  // ip4_net_part_matches



#define _ip4_addr_to_str( _s, _a ) \
  snprint_ip4_addr( _s, sizeof( _s ), _a, NULL )

#define _mac_addr_to_str( _s, _a ) \
  snprint_mac_addr( _s, sizeof( _s ), _a )



/* function prototypes: */

/* ----- function prototypes begin ----- */

/* This section was generated automatically */
/* by MAKEHDR, do not remove the comments. */

 /**
 * @brief Count the number of sequential bits set starting from MSB
 *
 * E.g. for 0xC0 and 0xC1 the results are both 2 since only
 * the 2 MSBs are sequentially set.
 *
 * @param p_mask  The IP4 net mask
 *
 * @return The number of sequential MSB bits set in val
 *
 * @see ip4_net_mask_from_cidr
 */
 int get_ip4_net_mask_bits( const IP4_ADDR *p_mask ) ;

 /**
 * @brief Print an IPv4 address to a dotted quad format string.
 *
 * @param s        The string buffer into which to print
 * @param max_len  Maximum length of the string, i.e. size of the buffer
 * @param p_addr   The IPv4 address
 * @param info     An optional string which is prepended to the string, or NULL
 *
 * @return The overall number of characters printed to the string
 *
 * @see snprint_ip4_cidr_addr
 * @see str_to_ip4_addr
 * @see cidr_str_to_ip4_addr_and_net_mask
 */
 int snprint_ip4_addr( char *s, size_t max_len, const IP4_ADDR *p_addr, const char *info ) ;

 /**
 * @brief Print an IPv4 address plus net mask to string in CIDR notation.
 *
 * The printed CIDR string is something like "172.16.3.250/24"
 *
 * @param s        The string buffer into which to print
 * @param max_len  Maximum length of the string, i.e. size of the buffer
 * @param p_addr   The IPv4 address
 * @param p_mask   The IPv4 net mask
 * @param info     An optional string which is prepended to the string, or NULL
 *
 * @return The overall number of characters printed to the string
 *
 * @see snprint_ip4_addr
 * @see str_to_ip4_addr
 * @see cidr_str_to_ip4_addr_and_net_mask
 */
 int snprint_ip4_cidr_addr( char *s, size_t max_len, const IP4_ADDR *p_addr, const IP4_ADDR *p_mask, const char *info ) ;

 /**
 * @brief Convert a string to an IP4_ADDR.
 *
 * @param p_addr  Pointer to the IP4_ADDR variable, or NULL, in which case this
 *                function can be used to check if the string is formally correct.
 * @param s       The string to be converted
 *
 * @return  >= 0  on success, number of characters evaluated from the input string
 *         -1  if invalid number found in string
 *         -2  if separator is not a dot '.'
 *
 * @see snprint_ip4_addr
 * @see snprint_ip4_cidr_addr
 * @see cidr_str_to_ip4_addr_and_net_mask
 */
 int str_to_ip4_addr( IP4_ADDR *p_addr, const char *s ) ;

 /**
 * @brief Convert a string in CIDR notation to an IP4_ADDR and net mask.
 *
 * @param p_addr   Pointer to an IP4_ADDR variable for the IP4 address,
 *                 or NULL, in which case this function can be used
 *                 to check if the string is formally correct.
 * @param p_mask   Pointer to an IP4_ADDR variable for the net mask,
 *                 or NULL, in which case this function can be used
 *                 to check if the string is formally correct.
 * @param cidr_str The string to be converted, in CIDR format, e.g. "172.16.3.250/24"
 *
 * @return  >= 0  on success, number of characters evaluated from the input string
 *          one of the ::MBG_LU_CODES on error
 *
 * @see snprint_ip4_addr
 * @see snprint_ip4_cidr_addr
 * @see str_to_ip4_addr
 */
 int cidr_str_to_ip4_addr_and_net_mask( IP4_ADDR *p_addr, IP4_ADDR *p_mask, const char *cidr_str ) ;

 /**
 * @brief Print a MAC ID or similar array of octets to a string.
 *
 * @param s           The string buffer into which to print
 * @param max_len     Maximum length of the string, i.e. size of the buffer
 * @param octets      An array of octets
 * @param num_octets  The number of octets to be printed from the array
 * @param sep         The separator printed between the bytes, or 0
 * @param info        An optional string which is prepended to the output, or NULL
 *
 * @return  The overall number of characters printed to the string
 *
 * @see snprint_mac_addr
 * @see str_to_octets
 * @see check_octets_not_all_zero
 */
 int snprint_octets( char *s, size_t max_len, const uint8_t *octets, int num_octets, char sep, const char *info ) ;

 /**
 * @brief Print a MAC address to a string.
 *
 * @param s           The string buffer into which to print
 * @param max_len     Maximum length of the string, i.e. size of the buffer
 * @param p_mac_addr  The MAC address to be printed
 *
 * @return  The overall number of characters printed to the string
 *
 * @see snprint_octets
 * @see str_to_octets
 * @see check_octets_not_all_zero
 */
 int snprint_mac_addr( char *s, size_t max_len, const MBG_MAC_ADDR *p_mac_addr ) ;

 /**
 * @brief Set a MAC ID or a similar array of octets from a string.
 *
 * @param octets      An array of octets to be set up
 * @param num_octets  The number of octets which can be stored
 * @param s           The string to be converted
 *
 * @return  The overall number of octets decoded from the string
 *
 * @see snprint_octets
 * @see snprint_mac_addr
 * @see check_octets_not_all_zero
 */
 int str_to_octets( uint8_t *octets, int num_octets, const char *s ) ;

 /**
 * @brief Check if an array of octets is valid, i.e. != 0
 *
 * @param octets      Pointer to the array of octets
 * @param num_octets  Number of octets
 *
 * @return MBG_LU_SUCCESS      octets are valid, i.e. not all 0
 *         MBG_LU_ERR_NOT_SET  octets are invalid, i.e. all 0
 *
 * @see snprint_octets
 * @see snprint_mac_addr
 * @see str_to_octets
 */
 int check_octets_not_all_zero( const uint8_t *octets, int num_octets ) ;

 /**
 * @brief Check if an array of octets is valid, i.e. != 0
 *
 * @param p_addr      Pointer to a MAC address
 *
 * @return MBG_LU_SUCCESS      MAC address is valid, i.e. not all 0
 *         MBG_LU_ERR_NOT_SET  MAC address is invalid, i.e. all 0
 *
 * @see check_octets_not_all_zero
 */
 int check_mac_addr_not_all_zero( const MBG_MAC_ADDR *p_addr ) ;

 /**
 * @brief Do a SIOCGxxx IOCTL call to read specific information from a LAN interface
 *
 * @param if_name     Name of the interface
 * @param ioctl_code  One of the predefined system SIOCGxxx IOCTL codes
 * @param p_ifreq     Pointer to a request buffer
 *
 * @return  one of the ::MBG_LU_CODES
 */
 int do_siocg_ioctl( const char *if_name, int ioctl_code, struct ifreq *p_ifreq ) ;

 /**
 * @brief Retrieve the MAC address of a network interface
 *
 * @param if_name     Name of the interface
 * @param p_mac_addr  Pointer to the MAC address buffer to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *          on error the MAC addr is set to all 0
 *
 * @see get_port_mac_addr_check
 */
 int get_port_mac_addr( const char *if_name, MBG_MAC_ADDR *p_mac_addr ) ;

 /**
 * @brief Retrieve and check the MAC address of a network interface
 *
 * @param if_name   Name of the interface
 * @param p_mac_addr  Pointer to the MAC address buffer to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *          on error the MAC addr is set to all 0
 *
 * @see get_port_mac_addr
 */
 int get_port_mac_addr_check( const char *if_name, MBG_MAC_ADDR *p_mac_addr ) ;

 /**
 * @brief Check the link state of a network interface
 *
 * @param if_name  Name of the interface
 *
 * @return 1 link detected on port
 *         0 no link detected on port
 *         one of the ::MBG_LU_CODES in case of an error
 */
 int check_port_link( const char *if_name ) ;

 /**
 * @brief Retrieve the IPv4 address of a network interface
 *
 * @param if_name   Name of the interface
 * @param p_addr    Pointer to address field to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
 int get_port_ip4_addr( const char *if_name, IP4_ADDR *p_addr ) ;

 /**
 * @brief Retrieve the IPv4 net mask of a network interface
 *
 * @param if_name   Name of the interface
 * @param p_addr    Pointer to address field to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
 int get_port_ip4_netmask( const char *if_name, IP4_ADDR *p_addr ) ;

 /**
 * @brief Retrieve the IPv4 broadcast address of a network interface
 *
 * @param if_name   Name of the interface
 * @param p_addr    Pointer to address field to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
 int get_port_ip4_broad_addr( const char *if_name, IP4_ADDR *p_addr ) ;

 /**
 * @brief Retrieve the IPv4 gateway (default route)
 *
 * @param p_addr  Pointer to address field to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 */
 int get_ip4_gateway( IP4_ADDR *p_addr ) ;

 /**
 * @brief Retrieve the IPv4 address of a network interface as string
 *
 * @param if_name     Name of the interface
 * @param p_addr_buf  Pointer to the string buffer to be filled up
 * @param buf_size    size of the string buffer
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
 int get_port_ip4_addr_str( const char *if_name, char *p_addr_buf, int buf_size ) ;

 /**
 * @brief Retrieve the IPv4 net mask of a network interface as string
 *
 * @param if_name     Name of the interface
 * @param p_addr_buf  Pointer to the string buffer to be filled up
 * @param buf_size    size of the string buffer
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
 int get_port_ip4_netmask_str( const char *if_name, char *p_addr_buf, int buf_size ) ;

 /**
 * @brief Retrieve the IPv4 broadcast address of a network interface as string
 *
 * @param if_name     Name of the interface
 * @param p_addr_buf  Pointer to the string buffer to be filled up
 * @param buf_size    size of the string buffer
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_specific_port_ip4_addr
 */
 int get_port_ip4_broad_addr_str( const char *if_name, char *p_addr_buf, int buf_size ) ;

 /**
 * @brief Retrieve the current IPv4 settings of a network interface
 *
 * @param if_name  Name of the interface
 * @param p        Pointer to a IP4_SETTINGS structure to be filled up
 *
 * @return 0 on success, < 0 on error
 *
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
 int get_port_ip4_settings( const char *if_name, IP4_SETTINGS *p ) ;


/* ----- function prototypes end ----- */

#ifdef __cplusplus
}
#endif


#if defined( _USING_BYTE_ALIGNMENT )
  #pragma pack()      // set default alignment
  #undef _USING_BYTE_ALIGNMENT
#endif

/* End of header body */


#undef _ext
#undef _DO_INIT

#endif  /* _LAN_UTIL_H */

