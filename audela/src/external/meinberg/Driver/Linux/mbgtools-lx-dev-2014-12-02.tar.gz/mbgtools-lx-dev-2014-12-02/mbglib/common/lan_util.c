
/**************************************************************************
 *
 *  $Id: lan_util.c 1.5 2013/02/19 15:13:10 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Utility functions useful for network programming.
 *
 * -----------------------------------------------------------------------
 *  $Log: lan_util.c $
 *  Revision 1.5  2013/02/19 15:13:10  martin
 *  Added some new functions.
 *  Updated doxygen comments.
 *  Revision 1.4  2012/11/02 09:16:57  martin
 *  Fixed build under Windows.
 *  Revision 1.3  2012/10/02 18:23:28Z  martin
 *  Removed obsolete code to avoid compiler warning.
 *  Revision 1.2  2012/03/09 08:49:19  martin
 *  Added some commonly used functions.
 *  Revision 1.1  2011/03/04 10:01:32Z  martin
 *  Initial revision.
 *
 **************************************************************************/

#define _LAN_UTIL
  #include <lan_util.h>
#undef _LAN_UTIL

#include <stdio.h>
#include <string.h>

#if defined ( MBG_TGT_UNIX )

  #if defined ( MBG_TGT_LINUX )

    #include <linux/types.h>

    // Some older versions of linux/types.h don't define u8..u64
    // for user space applications. However, if they do they also
    // define BITS_PER_LONG, so we use this symbol to figure out
    // if we need to define u8..u64 by ourselves.
    #if !defined( BITS_PER_LONG )
      typedef uint8_t u8;
      typedef uint16_t u16;
      typedef uint32_t u32;
      typedef uint64_t u64;
    #endif

    #include <linux/sockios.h>
    #include <linux/ethtool.h>
    #include <linux/rtnetlink.h>
  #endif

  #include <unistd.h>
  #include <sys/ioctl.h>
  #include <arpa/inet.h>
  #include <netinet/in.h>

#else

  // dummy codes, the functions will report an error ...
  #define SIOCGIFADDR      0
  #define SIOCGIFNETMASK   0
  #define SIOCGIFBRDADDR   0

  #if defined( MBG_TGT_WIN32 )
    #define snprintf _snprintf
  #endif

#endif


// Maximum size of an IPv4 address string in dotted quad format,
// including a terminating 0, and thus the required minimum size
// for a buffer to take such a string. i.e. "aaa.bbb.ccc.ddd\0".
#define MAX_IP4_ADDR_STR_SIZE   16


#if defined ( MBG_TGT_LINUX )

struct route_info
{
  struct in_addr dstAddr;
  struct in_addr srcAddr;
  struct in_addr gateWay;
  char ifName[IF_NAMESIZE];
};

#endif


#if defined( __BORLANDC__ ) \
    && ( __BORLANDC__ <= 0x410 )   // BC3.1 defines 0x410 !

#include <stdarg.h>

// Declare a snprintf() function if not provided by the
// build environment, though this implementation actually
// does not check the string length  ...

static /*HDR*/
int snprintf( char *s, size_t max_len, const char *fmt, ... )
{
  int n;
  va_list arg_list;

  va_start( arg_list, fmt );
  n = vsprintf( s, fmt, arg_list );
  va_end( arg_list );

  return n;

}  // snprintf

#endif



/*HDR*/
/**
 * @brief Count the number of sequential bits set starting from MSB
 *
 * E.g. for 0xC0 and 0xC1 the results are both 2 since only
 * the 2 MSBs are sequentially set.
 *
 * @param p_mask  The IP4 net mask
 *
 * @return The number of sequential MSB bits set in val
 *
 * @see ip4_net_mask_from_cidr
 */
int get_ip4_net_mask_bits( const IP4_ADDR *p_mask )
{
  IP4_ADDR msb_mask = IP4_MSB_MASK;
  int i;

  for ( i = 0; i < MAX_IP4_BITS; i++ )
  {
    if ( ( *p_mask & msb_mask ) == 0 )
      break;

    msb_mask >>= 1;
  }

  return i;

}  // get_ip4_net_mask_bits



/*HDR*/
/**
 * @brief Print an IPv4 address to a dotted quad format string.
 *
 * @param s        The string buffer into which to print
 * @param max_len  Maximum length of the string, i.e. size of the buffer
 * @param p_addr   The IPv4 address
 * @param info     An optional string which is prepended to the string, or NULL
 *
 * @return The overall number of characters printed to the string
 *
 * @see snprint_ip4_cidr_addr
 * @see str_to_ip4_addr
 * @see cidr_str_to_ip4_addr_and_net_mask
 */
int snprint_ip4_addr( char *s, size_t max_len, const IP4_ADDR *p_addr, const char *info )
{
  int n = 0;
  ulong ul = *p_addr;

  if ( info )
    n += snprintf( s, max_len, "%s", info );

  // Don't use byte pointers here since this is not safe
  // for both little and big endian targets.
  n += snprintf( &s[n], max_len - n, "%lu.%lu.%lu.%lu",
                 BYTE_3( ul ), BYTE_2( ul ),
                 BYTE_1( ul ), BYTE_0( ul )
               );
  return n;

}  // snprint_ip4_addr



/*HDR*/
/**
 * @brief Print an IPv4 address plus net mask to string in CIDR notation.
 *
 * The printed CIDR string is something like "172.16.3.250/24"
 *
 * @param s        The string buffer into which to print
 * @param max_len  Maximum length of the string, i.e. size of the buffer
 * @param p_addr   The IPv4 address
 * @param p_mask   The IPv4 net mask
 * @param info     An optional string which is prepended to the string, or NULL
 *
 * @return The overall number of characters printed to the string
 *
 * @see snprint_ip4_addr
 * @see str_to_ip4_addr
 * @see cidr_str_to_ip4_addr_and_net_mask
 */
int snprint_ip4_cidr_addr( char *s, size_t max_len, const IP4_ADDR *p_addr,
                           const IP4_ADDR *p_mask, const char *info )
{
  int cidr_mask_bits;
  IP4_ADDR normalized_addr = ip4_net_part_from_addr( p_addr, p_mask );

  int n = snprint_ip4_addr( s, max_len, &normalized_addr, info );

  cidr_mask_bits = get_ip4_net_mask_bits( p_mask );

  if ( ( cidr_mask_bits >= MIN_IP4_CIDR_NETMASK_BITS ) &&
       ( cidr_mask_bits <= MAX_IP4_CIDR_NETMASK_BITS ) )
    n += snprintf( &s[n], max_len - n, "/%i", cidr_mask_bits );

  return n;

}  // snprint_ip4_cidr_addr



/*HDR*/
/**
 * @brief Convert a string to an IP4_ADDR.
 *
 * @param p_addr  Pointer to the IP4_ADDR variable, or NULL, in which case this
 *                function can be used to check if the string is formally correct.
 * @param s       The string to be converted
 *
 * @return  >= 0  on success, number of characters evaluated from the input string
 *         -1  if invalid number found in string
 *         -2  if separator is not a dot '.'
 *
 * @see snprint_ip4_addr
 * @see snprint_ip4_cidr_addr
 * @see cidr_str_to_ip4_addr_and_net_mask
 */
int str_to_ip4_addr( IP4_ADDR *p_addr, const char *s )
{
  IP4_ADDR tmp_ip4_addr = 0;
  const char *cp;
  int i;

  for ( i = 0, cp = (char *) s; ; )
  {
    unsigned long ul = strtoul( (char *) cp, (char **) &cp, 10 );

    if ( ul > 255 )  // invalid number
      return -1;

    tmp_ip4_addr |= ul << ( 8 * (3 - i) );

    if ( ++i >= 4 )
      break;        // done

    if ( *cp != '.' )
      return -2;    // invalid string format, dot expected

    cp++;  // skip dot
  }

  if ( p_addr )
    *p_addr = tmp_ip4_addr;

  // success: return the number of evaluated chars
  return cp - s;

}  // str_to_ip4_addr



/*HDR*/
/**
 * @brief Convert a string in CIDR notation to an IP4_ADDR and net mask.
 *
 * @param p_addr   Pointer to an IP4_ADDR variable for the IP4 address,
 *                 or NULL, in which case this function can be used
 *                 to check if the string is formally correct.
 * @param p_mask   Pointer to an IP4_ADDR variable for the net mask,
 *                 or NULL, in which case this function can be used
 *                 to check if the string is formally correct.
 * @param cidr_str The string to be converted, in CIDR format, e.g. "172.16.3.250/24"
 *
 * @return  >= 0  on success, number of characters evaluated from the input string
 *          one of the ::MBG_LU_CODES on error
 *
 * @see snprint_ip4_addr
 * @see snprint_ip4_cidr_addr
 * @see str_to_ip4_addr
 */
int cidr_str_to_ip4_addr_and_net_mask( IP4_ADDR *p_addr, IP4_ADDR *p_mask,
                                       const char *cidr_str )
{
  IP4_ADDR mask;
  long cidr_mask_bits;
  const char *cp;
  int l;
  int rc = str_to_ip4_addr( p_addr, cidr_str );

  if ( rc < 0 )  // return current error
    return rc;


  l = strlen( cidr_str );

  if ( l < rc )  // input string too short
    return MBG_LU_ERR_FMT;


  cp = &cidr_str[rc];

  if ( *cp == 0 )  // end of string
  {
    // The string has no CIDR extension, so
    // assume "/0", i.e. host mask 255.255.255.255;
    mask = (IP4_ADDR) -1;
    goto done;
  }


  if ( *cp != '/' )
    return MBG_LU_ERR_FMT;


  cp++;
  cidr_mask_bits = strtol( (char *) cp, (char **) &cp, 10 );

  if ( ( cidr_mask_bits < MIN_IP4_CIDR_NETMASK_BITS ) ||
       ( cidr_mask_bits > MAX_IP4_CIDR_NETMASK_BITS ) )
    return MBG_LU_ERR_RANGE;


  mask = ip4_net_mask_from_cidr( (int) cidr_mask_bits );

done:
  if ( p_mask )
    *p_mask = mask;

  // success: return the number of evaluated chars
  return  cp - cidr_str;

}  // cidr_str_to_ip4_addr_and_net_mask



/*HDR*/
/**
 * @brief Print a MAC ID or similar array of octets to a string.
 *
 * @param s           The string buffer into which to print
 * @param max_len     Maximum length of the string, i.e. size of the buffer
 * @param octets      An array of octets
 * @param num_octets  The number of octets to be printed from the array
 * @param sep         The separator printed between the bytes, or 0
 * @param info        An optional string which is prepended to the output, or NULL
 *
 * @return  The overall number of characters printed to the string
 *
 * @see snprint_mac_addr
 * @see str_to_octets
 * @see check_octets_not_all_zero
 */
int snprint_octets( char *s, size_t max_len, const uint8_t *octets,
                    int num_octets, char sep, const char *info )
{
  int n = 0;
  int i;

  if ( info )
    n += snprintf( s, max_len, "%s", info );

  for ( i = 0; i < num_octets; i++ )
  {
    if ( i && sep )
      n += snprintf( &s[n], max_len - n, "%c", sep );

    n += snprintf( &s[n], max_len - n, "%02X", octets[i] );
  }

  return n;

}  // snprint_octets



/*HDR*/
/**
 * @brief Print a MAC address to a string.
 *
 * @param s           The string buffer into which to print
 * @param max_len     Maximum length of the string, i.e. size of the buffer
 * @param p_mac_addr  The MAC address to be printed
 *
 * @return  The overall number of characters printed to the string
 *
 * @see snprint_octets
 * @see str_to_octets
 * @see check_octets_not_all_zero
 */
int snprint_mac_addr( char *s, size_t max_len, const MBG_MAC_ADDR *p_mac_addr )
{
  return snprint_octets( s, max_len, p_mac_addr->b, sizeof( *p_mac_addr ), MAC_SEP_CHAR, NULL );

}  // snprint_mac_addr



/*HDR*/
/**
 * @brief Set a MAC ID or a similar array of octets from a string.
 *
 * @param octets      An array of octets to be set up
 * @param num_octets  The number of octets which can be stored
 * @param s           The string to be converted
 *
 * @return  The overall number of octets decoded from the string
 *
 * @see snprint_octets
 * @see snprint_mac_addr
 * @see check_octets_not_all_zero
 */
int str_to_octets( uint8_t *octets, int num_octets, const char *s )
{
  char *cp = (char *) s;
  int i;

  // don't use strtok() since that functions modifies the original string
  for ( i = 0; i < num_octets; )
  {
    octets[i] = (uint8_t) strtoul( cp, &cp, 16 );
    i++;

    if ( *cp == 0 )
      break;      // end of string

    if ( ( *cp != MAC_SEP_CHAR ) && ( *cp != MAC_SEP_CHAR_ALT ) )
      break;      // invalid character

    cp++;
  }

  return i;

}  // str_to_octets



/*HDR*/
/**
 * @brief Check if an array of octets is valid, i.e. != 0
 *
 * @param octets      Pointer to the array of octets
 * @param num_octets  Number of octets
 *
 * @return MBG_LU_SUCCESS      octets are valid, i.e. not all 0
 *         MBG_LU_ERR_NOT_SET  octets are invalid, i.e. all 0
 *
 * @see snprint_octets
 * @see snprint_mac_addr
 * @see str_to_octets
 */
int check_octets_not_all_zero( const uint8_t *octets, int num_octets )
{
  int i;

  // check if any of the MAC adddress bytes is != 0
  for ( i = 0; i < num_octets; i++ )
    if ( octets[i] != 0 )
      break;

  if ( i == num_octets ) // *all* bytes are 0
    return MBG_LU_ERR_NOT_SET;

  return 0;

}  // check_octets_not_all_zero



/*HDR*/
/**
 * @brief Check if an array of octets is valid, i.e. != 0
 *
 * @param p_addr      Pointer to a MAC address
 *
 * @return MBG_LU_SUCCESS      MAC address is valid, i.e. not all 0
 *         MBG_LU_ERR_NOT_SET  MAC address is invalid, i.e. all 0
 *
 * @see check_octets_not_all_zero
 */
int check_mac_addr_not_all_zero( const MBG_MAC_ADDR *p_addr )
{
  return check_octets_not_all_zero( p_addr->b, sizeof( p_addr->b ) );

}  // check_mac_addr_not_all_zero



#if defined( MBG_TGT_UNIX )

/*HDR*/
/**
 * @brief Do a SIOCGxxx IOCTL call to read specific information from a LAN interface
 *
 * @param if_name     Name of the interface
 * @param ioctl_code  One of the predefined system SIOCGxxx IOCTL codes
 * @param p_ifreq     Pointer to a request buffer
 *
 * @return  one of the ::MBG_LU_CODES
 */
int do_siocg_ioctl( const char *if_name, int ioctl_code, struct ifreq *p_ifreq )
{
  int fd;
  int rc;

  if ( strlen( if_name ) > ( IFNAMSIZ - 1 ) )
    return MBG_LU_ERR_PORT_NAME;

  fd = socket( AF_INET, SOCK_DGRAM, 0 );

  if ( fd < 0 )
    return MBG_LU_ERR_SOCKET;

  strcpy( p_ifreq->ifr_name, if_name );

  rc = ioctl( fd, ioctl_code, p_ifreq );

  if ( rc < 0 )
    rc = MBG_LU_ERR_IOCTL;

  close( fd );

  return MBG_LU_SUCCESS;

}  // do_siocg_ioctl

#endif  //  defined( MBG_TGT_UNIX )



/*HDR*/
/**
 * @brief Retrieve the MAC address of a network interface
 *
 * @param if_name     Name of the interface
 * @param p_mac_addr  Pointer to the MAC address buffer to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *          on error the MAC addr is set to all 0
 *
 * @see get_port_mac_addr_check
 */
int get_port_mac_addr( const char *if_name, MBG_MAC_ADDR *p_mac_addr )
{
  int rc = MBG_LU_ERR_NSUPP;

  #if defined( MBG_TGT_LINUX )
    struct ifreq ifr = { { { 0 } } };

    rc = do_siocg_ioctl( if_name, SIOCGIFHWADDR, &ifr );

    if ( rc != MBG_LU_SUCCESS )
      goto fail;

    memcpy( p_mac_addr, ifr.ifr_hwaddr.sa_data, sizeof( *p_mac_addr ) );

    return rc;

fail:
  #endif

  memset( p_mac_addr, 0, sizeof( *p_mac_addr ) );

  return rc;

}  // get_port_mac_addr



/*HDR*/
/**
 * @brief Retrieve and check the MAC address of a network interface
 *
 * @param if_name   Name of the interface
 * @param p_mac_addr  Pointer to the MAC address buffer to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *          on error the MAC addr is set to all 0
 *
 * @see get_port_mac_addr
 */
int get_port_mac_addr_check( const char *if_name, MBG_MAC_ADDR *p_mac_addr )
{
  int rc = get_port_mac_addr( if_name, p_mac_addr );

  if ( rc == MBG_LU_SUCCESS )
    rc = check_octets_not_all_zero( p_mac_addr->b, sizeof( *p_mac_addr ) );

  return rc;

}  // get_port_mac_addr_check



/*HDR*/
/**
 * @brief Check the link state of a network interface
 *
 * @param if_name  Name of the interface
 *
 * @return 1 link detected on port
 *         0 no link detected on port
 *         one of the ::MBG_LU_CODES in case of an error
 */
int check_port_link( const char *if_name )
{
  #if defined( MBG_TGT_LINUX )
    struct ifreq ifr = { { { 0 } } };
    struct ethtool_value edata = { 0 };
    int rc;

    edata.cmd = ETHTOOL_GLINK; // defined in ethtool.h
    ifr.ifr_data = (caddr_t) &edata;

    rc = do_siocg_ioctl( if_name, SIOCETHTOOL, &ifr );

    if ( rc == MBG_LU_SUCCESS )
      rc = edata.data != 0;

    return rc;

  #else

    return MBG_LU_ERR_NSUPP;

  #endif

}  // check_port_link



static /*HDR*/
/**
 * @brief Retrieve some IPv4 address like info from a network interface
 *
 * @param if_name      Name of the interface
 * @param p_addr       Pointer to address field to be filled up
 * @param sigioc_code  the ioctl code associated to the address
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 */
int get_specific_port_ip4_addr( const char *if_name, IP4_ADDR *p_addr, int sigioc_code )
{
  int rc = MBG_LU_ERR_NSUPP;

  #if defined( MBG_TGT_LINUX )
    struct ifreq ifr = { { { 0 } } };

    rc = do_siocg_ioctl( if_name, sigioc_code, &ifr );

    if ( rc != MBG_LU_SUCCESS )
      goto fail;

    *p_addr = ntohl( ( (struct sockaddr_in *) &ifr.ifr_addr )->sin_addr.s_addr );

    return rc;

fail:
  #endif

  *p_addr = 0;  // make empty address

  return rc;

}  // get_specific_port_ip4_addr



/*HDR*/
/**
 * @brief Retrieve the IPv4 address of a network interface
 *
 * @param if_name   Name of the interface
 * @param p_addr    Pointer to address field to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
int get_port_ip4_addr( const char *if_name, IP4_ADDR *p_addr )
{
  return get_specific_port_ip4_addr( if_name, p_addr, SIOCGIFADDR );

}  // get_port_ip4_addr



/*HDR*/
/**
 * @brief Retrieve the IPv4 net mask of a network interface
 *
 * @param if_name   Name of the interface
 * @param p_addr    Pointer to address field to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
int get_port_ip4_netmask( const char *if_name, IP4_ADDR *p_addr )
{
  return get_specific_port_ip4_addr( if_name, p_addr, SIOCGIFNETMASK );

}  // get_port_ip4_netmask



/*HDR*/
/**
 * @brief Retrieve the IPv4 broadcast address of a network interface
 *
 * @param if_name   Name of the interface
 * @param p_addr    Pointer to address field to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
int get_port_ip4_broad_addr( const char *if_name, IP4_ADDR *p_addr )
{
  return get_specific_port_ip4_addr( if_name, p_addr, SIOCGIFBRDADDR );

}  // get_port_ip4_broad_addr



#if defined( MBG_TGT_LINUX )

static /*HDR*/
int readNlSock( int sockFd, char *bufPtr, size_t buf_size, int seqNum, int pId )
{
  struct nlmsghdr *nlHdr;
  int readLen = 0;
  int msgLen = 0;

  do
  {
    /* Receive response from the kernel */
    if ( ( readLen = recv( sockFd, bufPtr, buf_size - msgLen, 0 ) ) < 0 )
    {
      #if defined( DEBUG )
        perror( "Failed to receive netlink packet" );
      #endif
      return -1;
    }

    nlHdr = (struct nlmsghdr *) bufPtr;

    /* Check if the header is valid */
    if ( ( NLMSG_OK( nlHdr, readLen ) == 0 ) || ( nlHdr->nlmsg_type == NLMSG_ERROR ) )
    {
      #if defined( DEBUG )
        fprintf( stderr, "Invalid header in received netlink packet\n" );
      #endif
      return -1;
    }

    /* Check if the its the last message */
    if ( nlHdr->nlmsg_type == NLMSG_DONE )
      break;

    /* Else move the pointer to buffer appropriately */
    bufPtr += readLen;
    msgLen += readLen;

    /* Check if its a multi part message */
    if ( ( nlHdr->nlmsg_flags & NLM_F_MULTI ) == 0 )
    {
      /* return if its not */
      break;
    }

  } while ( ( nlHdr->nlmsg_seq != seqNum ) || ( nlHdr->nlmsg_pid != pId ) );

  return msgLen;

}  // readNlSock



static /*HDR*/
void parseRoutes( struct nlmsghdr *nlHdr, struct route_info *rtInfo )
{ /* parse the route info returned */
  struct rtmsg *rtMsg;
  struct rtattr *rtAttr;
  int rtLen;

  rtMsg = (struct rtmsg *) NLMSG_DATA( nlHdr );

  /* If the route is not for AF_INET or does not belong to main routing table then return. */
  if ( ( rtMsg->rtm_family != AF_INET ) || ( rtMsg->rtm_table != RT_TABLE_MAIN ) )
    return;

  /* get the rtattr field */
  rtAttr = (struct rtattr *) RTM_RTA( rtMsg );
  rtLen = RTM_PAYLOAD( nlHdr );

  for( ; RTA_OK( rtAttr, rtLen ); rtAttr = RTA_NEXT( rtAttr, rtLen ) )
  {
    switch( rtAttr->rta_type )
    {
      case RTA_OIF:
        if_indextoname( *(int *)RTA_DATA( rtAttr ), rtInfo->ifName );
        break;

      case RTA_GATEWAY:
        memcpy( &rtInfo->gateWay, RTA_DATA( rtAttr ), sizeof( rtInfo->gateWay ) );
        break;

      case RTA_PREFSRC:
        memcpy( &rtInfo->srcAddr , RTA_DATA( rtAttr ), sizeof( rtInfo->srcAddr ) );
        break;

      case RTA_DST:
        memcpy( &rtInfo->dstAddr, RTA_DATA( rtAttr ), sizeof( rtInfo->dstAddr ) );
        break;
    }
  }

}  // parseRoutes

#endif  // defined( MBG_TGT_LINUX )



/*HDR*/
/**
 * @brief Retrieve the IPv4 gateway (default route)
 *
 * @param p_addr  Pointer to address field to be filled up
 *
 * @return  one of the ::MBG_LU_CODES
 */
int get_ip4_gateway( IP4_ADDR *p_addr )
{
  int ret_val = MBG_LU_ERR_NOT_SET;

#if defined( MBG_TGT_LINUX )
  struct nlmsghdr *nlMsg;
  struct route_info *rtInfo;
  char msgBuf[8192];   // pretty large buffer

  int sock;
  int len;
  int msgSeq = 0;


  /* Create Socket */

  if ( ( sock = socket( PF_NETLINK, SOCK_DGRAM, NETLINK_ROUTE ) ) < 0 )
  {
    #if defined( DEBUG )
      perror( "Failed to create netlink socket" );
    #endif
    ret_val = MBG_LU_ERR_SOCKET;
    goto out;
  }


  /* Initialize the buffer */
  memset( msgBuf, 0, sizeof( msgBuf ) );

  /* point the header and the msg structure pointers into the buffer */
  nlMsg = (struct nlmsghdr *) msgBuf;

  /* Fill in the nlmsg header*/
  nlMsg->nlmsg_len = NLMSG_LENGTH( sizeof( struct rtmsg ) ); // Length of message
  nlMsg->nlmsg_type = RTM_GETROUTE; // Get the routes from kernel routing table

  nlMsg->nlmsg_flags = NLM_F_DUMP | NLM_F_REQUEST; // The message is a request for dump
  nlMsg->nlmsg_seq = msgSeq++; // Sequence of the message packet.
  nlMsg->nlmsg_pid = getpid(); // PID of process sending the request.

  /* Send the request */
  if ( send( sock, nlMsg, nlMsg->nlmsg_len, 0 ) < 0 )
  {
    #if defined( DEBUG )
      perror( "Failed to write to netlink socket" );
    #endif
    ret_val = -1;
    goto out;
  }

  /* Read the response */
  if ( ( len = readNlSock( sock, msgBuf, sizeof( msgBuf ), msgSeq, getpid() ) ) < 0 )
  {
    ret_val = -1;
    goto out;
  }

  /* Parse and print the response */
  rtInfo = (struct route_info *) malloc( sizeof( struct route_info ) );

  for( ; NLMSG_OK( nlMsg, len ); nlMsg = NLMSG_NEXT( nlMsg, len ) )
  {
    memset( rtInfo, 0, sizeof( *rtInfo ) );
    parseRoutes( nlMsg, rtInfo );

    // Check if default gateway
    if ( strstr( (char *) inet_ntoa( rtInfo->dstAddr ), "0.0.0.0" ) )
    {
      *p_addr = ntohl( rtInfo->gateWay.s_addr );
      ret_val = MBG_LU_SUCCESS;
      break;
    }
  }

  free( rtInfo );

out:
  if ( sock >= 0 )
    close( sock );

#endif  // defined( MBG_TGT_LINUX )


  if ( ret_val != MBG_LU_SUCCESS )
    *p_addr = 0;

  return ret_val;

}  // get_ip4_gateway



/*HDR*/
/**
 * @brief Retrieve the IPv4 address of a network interface as string
 *
 * @param if_name     Name of the interface
 * @param p_addr_buf  Pointer to the string buffer to be filled up
 * @param buf_size    size of the string buffer
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
int get_port_ip4_addr_str( const char *if_name, char *p_addr_buf, int buf_size )
{
  IP4_ADDR addr;

  int rc = get_port_ip4_addr( if_name, &addr );

  snprint_ip4_addr( p_addr_buf, buf_size, &addr, NULL );

  return rc;

}  // get_port_ip4_addr_str



/*HDR*/
/**
 * @brief Retrieve the IPv4 net mask of a network interface as string
 *
 * @param if_name     Name of the interface
 * @param p_addr_buf  Pointer to the string buffer to be filled up
 * @param buf_size    size of the string buffer
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
int get_port_ip4_netmask_str( const char *if_name, char *p_addr_buf, int buf_size )
{
  IP4_ADDR addr;

  int rc = get_port_ip4_netmask( if_name, &addr );

  snprint_ip4_addr( p_addr_buf, buf_size, &addr, NULL );

  return rc;

}  // get_port_ip4_netmask_str



/*HDR*/
/**
 * @brief Retrieve the IPv4 broadcast address of a network interface as string
 *
 * @param if_name     Name of the interface
 * @param p_addr_buf  Pointer to the string buffer to be filled up
 * @param buf_size    size of the string buffer
 *
 * @return  one of the ::MBG_LU_CODES
 *
 * @see get_port_ip4_settings
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_specific_port_ip4_addr
 */
int get_port_ip4_broad_addr_str( const char *if_name, char *p_addr_buf, int buf_size )
{
  IP4_ADDR addr;

  int rc = get_port_ip4_broad_addr( if_name, &addr );

  snprint_ip4_addr( p_addr_buf, buf_size, &addr, NULL );

  return rc;

}  // get_port_ip4_broad_addr_str



/*HDR*/
/**
 * @brief Retrieve the current IPv4 settings of a network interface
 *
 * @param if_name  Name of the interface
 * @param p        Pointer to a IP4_SETTINGS structure to be filled up
 *
 * @return 0 on success, < 0 on error
 *
 * @see get_port_ip4_addr
 * @see get_port_ip4_addr_str
 * @see get_port_ip4_netmask
 * @see get_port_ip4_netmask_str
 * @see get_port_ip4_broad_addr
 * @see get_port_ip4_broad_addr_str
 * @see get_specific_port_ip4_addr
 */
int get_port_ip4_settings( const char *if_name, IP4_SETTINGS *p )
{
  int link_up;
  int ret_val = 0;

  memset( p, 0, sizeof( *p ) );

  if ( get_port_ip4_addr( if_name, &p->ip_addr ) )
    ret_val = -1;

  if ( get_port_ip4_netmask( if_name, &p->netmask ) )
    ret_val = -1;

  if ( get_port_ip4_broad_addr( if_name, &p->broad_addr ) )
    ret_val = -1;

  if ( get_ip4_gateway( &p->gateway ) )
    ret_val = -1;


  link_up = check_port_link( if_name );

  if ( link_up )
    p->flags |= IP4_MSK_LINK;

#if 0  //##+++++
  // We could also try to check VLAN and DHCP settings here,
  // but as of now, this is specific to an application.

  // ##++++ The VLAN and DHCP status info collected below
  // just return what has been configured previously by this program,
  // however, it does not reflect any changes which have been made
  // manually, e.g. via the command line.
  if ( vlan_enabled )
  {
    p->flags |= IP4_MSK_VLAN;
    p->vlan_cfg = vlan_cfg;
  }

  if ( dhcp_enabled )
    p->flags |= IP4_MSK_DHCP;
#endif

  return ret_val;

}  // get_port_ip4_settings


