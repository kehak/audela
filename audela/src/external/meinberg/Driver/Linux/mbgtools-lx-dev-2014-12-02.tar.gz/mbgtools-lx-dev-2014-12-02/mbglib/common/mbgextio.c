
/**************************************************************************
 *
 *  $Id: mbgextio.c 1.15 2013/02/14 14:42:13 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Meinberg extended I/O functions for the binary data protocol
 *    via serial communication, network socket I/O, or direct USB I/O.
 *
 *    These functions can *not* be used to access LANTIME NTP servers,
 *    or the modules assembled within a LANTIME since LANTIMEs are using
 *    this kind of communication only internally.
 *
 *    Also, standalone USB devices are usually handled by the driver
 *    software package for the given operating system and thus can be
 *    accessed in the same way as PCI cards, using the API functions
 *    provided by the mbgdevio library.
 *
 *    These functions can be used, however, with standalone devices
 *    which are accessible either directly via a serial port, or via a
 *    special serial-to-LAN converter like the meinberg LAN_XPT module.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgextio.c $
 *  Revision 1.15  2013/02/14 14:42:13  martin
 *  Fixed syntax err due to unintentionally pasted word.
 *  Revision 1.14  2013/02/06 15:43:54  martin
 *  Updated doxygen comments.
 *  Revision 1.13  2013/02/01 15:58:43  martin
 *  In mbgextio_force_connection() for Windows wait until all chars
 *  must have been sent since flushing output buffer doesn't work reliably.
 *  Added a number of new functions.
 *  Added doxygen comments.
 *  Revision 1.12  2012/10/30 16:17:30  martin
 *  Started to migrate to opaque stuctures.
 *  Conditionally let xmt routines request for ACK packet,
 *  though this is by default disabled.
 *  Support receiving NACK status.
 *  Support big endian target platforms.
 *  Merged and adapted Daniel's USB support functions.
 *  Support event log entries.
 *  Syntax workaround which is required until this module becomes a DLL.
 *  Added some new functions.
 *  Updated doxygen comments.
 *  Huge cleanup.
 *  Revision 1.11  2011/04/15 13:17:14  martin
 *  Use common mutex support macros from mbgmutex.h.
 *  Revision 1.10  2011/04/08 11:28:24  martin
 *  Modified mbgextio_get_ucap() to account for different device behaviour.
 *  Added missing braces.
 *  Revision 1.9  2009/10/02 14:19:05  martin
 *  Added a bunch of missing functions.
 *  Revision 1.8  2009/10/01 11:10:51  martin
 *  Added functions to set/retrieve char and msg rcv timeout.
 *  Revision 1.7  2009/09/01 10:44:58  martin
 *  Cleanup for CVI.
 *  Use new portable timeout functions from mbg_tmo.h.
 *  Timeouts are now specified in milliseconds.
 *  Distinguish between character timeout and message timeout.
 *  Only fetch one character at a time to prevent received characters
 *  from being discarded after the end of one message.
 *  Revision 1.6  2009/03/10 17:02:08Z  martin
 *  Added support for configurable time scales.
 *  Added mbgextio_get_time() call.
 *  Fixed some compiler warnings.
 *  Revision 1.5  2008/09/04 14:35:50Z  martin
 *  Fixed opening COM port under CVI.
 *  Moved generic serial I/O stuff to mbgserio.c and mbgserio.h.
 *  Restart reception if received msg does not match expected cmd code.
 *  Fixed timeout value for Windows.
 *  New symbol _MBGEXTIO_DIRECT_RC controls whether the return code of the
 *  mbgextio_set_...() functions is evaluated or returned as-is.
 *  New functions mbgextio_set_time(), mbgextio_set_tzdl().
 *  Added mbgextio_get_ucap(). This may not work with older firmware,
 *  see the comments in mbgextio_get_ucap().
 *  Conditionally support checking of time strings.
 *  Revision 1.4  2007/02/27 10:35:19Z  martin
 *  Added mutex for transmit buffer to make transmission thread-safe.
 *  Fixed timeout handling for serial reception.
 *  Renamed mbgextio_get_data() to mbgextio_rcv_msg().
 *  Added some new functions.
 *  Temp. changes for parameter setting functions.
 *  Added comments on POSIX flags used when opening serial port.
 *  Revision 1.3  2006/12/21 10:56:17  martin
 *  Added function mbgextio_set_port_parm.
 *  Revision 1.2  2006/10/25 12:18:31  martin
 *  Support serial I/O under Windows.
 *  Revision 1.1  2006/08/24 12:40:37Z  martin
 *  Initial revision.
 *
 **************************************************************************/

#define _MBGEXTIO
  #include <mbgextio.h>
#undef _MBGEXTIO

#include <mbgserio.h>
#include <mbg_arch.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gpsutils.h>

#if defined( MBG_TGT_UNIX )
  #include <unistd.h>
  #include <fcntl.h>
#else
  typedef int ssize_t;
#endif


#if !defined( _MBGEXTIO_REQ_ACK )
  // If _MBGEXTIO_REQ_ACK is != 0 then mbgextio_...() functions writing
  // configuration parameters send the cmd code with the ACK request bit set
  // which lets mbgextio_xmt_msg() try to receive a response from the device
  // after the parameters have been sent.
  #define _MBGEXTIO_REQ_ACK     0
#endif

#if _MBGEXTIO_REQ_ACK
  #define OPT_GPS_ACK_CODE   GPS_REQACK
#else
  #define OPT_GPS_ACK_CODE   0   // dummy
#endif



// default serial message timeout
#if !defined ( MBGEXTIO_MSG_RCV_TIMEOUT_SERIAL )
  #define MBGEXTIO_MSG_RCV_TIMEOUT_SERIAL     3000  // [ms]
#endif

// default serial single character timeout
#if !defined ( MBGEXTIO_CHAR_RCV_TIMEOUT_SERIAL )
  #define MBGEXTIO_CHAR_RCV_TIMEOUT_SERIAL     200  // [ms]
#endif



static /*HDR*/
void dealloc_msg_ctl( MBG_MSG_CTL **ppmctl )
{
  MBG_MSG_CTL *pmctl = *ppmctl;

  if ( pmctl )
  {
    if ( pmctl->xmt.pmb )
    {
      free( pmctl->xmt.pmb );
      pmctl->xmt.pmb = NULL;
    }

    pmctl->xmt.buf_size = 0;

    if ( pmctl->xmt.pmb )
    {
      free( pmctl->xmt.pmb );
      pmctl->xmt.pmb = NULL;
    }

    pmctl->rcv.buf_size = 0;

    free( pmctl );
    *ppmctl = NULL;
  }

}  // dealloc_msg_ctl



static /*HDR*/
MBG_MSG_CTL *alloc_msg_ctl( void )
{
  MBG_MSG_CTL *pmctl = (MBG_MSG_CTL *) malloc( sizeof( *pmctl ) );

  if ( pmctl )
  {
    memset( pmctl, 0, sizeof( *pmctl ) );

    pmctl->rcv.buf_size = sizeof( *(pmctl->rcv.pmb) );
    pmctl->rcv.pmb = (MBG_MSG_BUFF *) malloc( pmctl->rcv.buf_size );

    pmctl->xmt.buf_size = sizeof( *(pmctl->xmt.pmb) );
    pmctl->xmt.pmb = (MBG_MSG_BUFF *) malloc( pmctl->xmt.buf_size );

    // if memory could not be allocated, clean up
    if ( ( pmctl->rcv.pmb == NULL ) || ( pmctl->xmt.pmb == NULL ) )
      dealloc_msg_ctl( &pmctl );  // also sets pmctl to NULL
  }

  return pmctl;

}  // alloc_msg_ctl



#if defined( MBG_TGT_WIN32 ) && _USE_SOCKET_IO

static /*HDR*/
BOOL WINAPI mbgextio_on_console_event( DWORD dwCtrlType )
{
  switch ( dwCtrlType )
  {
    case CTRL_BREAK_EVENT:
    case CTRL_C_EVENT:
    case CTRL_CLOSE_EVENT:
    case CTRL_SHUTDOWN_EVENT:
      exit( 0 );

  }  // switch

  return FALSE;

}  // mbgextio_on_console_event



static /*HDR*/
void mbgextio_set_console_control_handler( void )
{
  static int has_been_set;

  if ( !has_been_set )
  {
    SetConsoleCtrlHandler( mbgextio_on_console_event, TRUE );
    has_been_set = 1;
  }

}  // mbgextio_set_console_control_handler

#endif  //  defined MBG_TGT_WIN32




#if _USE_SOCKET_IO

static /*HDR*/
int socket_init( MBG_MSG_CTL *pmctl, const char *host )
{
  struct hostent *hp;
  struct sockaddr_in *paddr;
  const struct sockaddr *p;
  int sz;
  int rc;

  hp = gethostbyname( host );

  #if defined( MBG_TGT_WIN32 )
    if ( hp == NULL )
    {
      // The winsock2.dll may not yet have been initialized,
      // so try to initialize now.
      WORD wVersionRequested;
      WSADATA wsaData;

      wVersionRequested = MAKEWORD( 2, 2 );

      rc = WSAStartup( wVersionRequested, &wsaData );

      // If initialization has succeeded, try again.
      if ( rc == 0 )
        hp = gethostbyname( host );
    }
  #endif  // defined( MBG_TGT_WIN32 )

  if ( hp == NULL )
    return TR_OPEN_ERR;


  // create socket on which to send.
  pmctl->st.sockio.sockfd = socket( PF_INET, SOCK_STREAM, 0 );

  if ( pmctl->st.sockio.sockfd == INVALID_SOCKET )
    return TR_OPEN_ERR;

  paddr = &pmctl->st.sockio.addr;
  memset( paddr, 0, sizeof( *paddr ) );

  memcpy( &paddr->sin_addr, hp->h_addr, hp->h_length );
  paddr->sin_family = AF_INET;
  paddr->sin_port = htons( LAN_XPT_PORT );

  p = (const struct sockaddr *) paddr;
  sz = sizeof( *paddr );

  rc = connect( pmctl->st.sockio.sockfd, p, sz );

  if ( rc < 0 )
  {
    #if defined( MBG_TGT_WIN32 )
      DWORD err = WSAGetLastError();
      // e.g. WSAECONNREFUSED (10061): connection refused
    #endif
    return TR_OPEN_ERR;
  }

  return 0;

}  // socket_init



static /*HDR*/
int comm_init( MBG_MSG_CTL *pmctl, const char *passwd )
{
  SECU_SETTINGS *pss = &pmctl->secu_settings;
  MBG_MSG_BUFF *pmb;
  int rc;

  memset( pss, 0, sizeof *pss );
  strncpy( pss->password, passwd, sizeof( pss->password ) );

  pmctl->conn_type = MBG_CONN_TYPE_SOCKET;
  pmctl->msg_rcv_timeout = MBGEXTIO_RCV_TIMEOUT_SOCKET;
  // pmctl->char_rcv_timeout is not used with sockets

  set_encryption_mode( pmctl, MBG_XFER_MODE_ENCRYTED, pss->password );

  pmb = pmctl->xmt.pmb;
  pmb->u.msg_data.secu_settings = *pss;
  pmb->hdr.cmd = GPS_SECU_SETTINGS;
  pmb->hdr.len = sizeof( pmb->u.msg_data.secu_settings );

  xmt_tbuff( pmctl );
  rc = mbgextio_rcv_msg( pmctl, GPS_SECU_SETTINGS );

  if ( rc != TR_COMPLETE )
    return -1;  /* connection refused */

  pmb = pmctl->rcv.pmb;

  if ( !( pmb->hdr.cmd & GPS_ACK ) )
    return -2;  /* authentication failed */

  return 0;

}  // comm_init



/*HDR*/
/**
 * @brief Open a binary communication channel using LAN/socket connection
 *
 * See the common notes at the top of this file for details.
 *
 * @param host DNS name or IP address of the target device
 * @param passwd Password string for the encrypted communication
 *
 * @return A ::MBG_MSG_CTL control structure to be used with further API calls, or NULL on error
 *
 * @see mbgextio_open_serial
 * @see mbgextio_open_usb
 * @see mbgextio_close_connection
 */
_NO_MBG_API_ATTR MBG_MSG_CTL * _MBG_API mbgextio_open_socket( const char *host,
                                                              const char *passwd )
{
  MBG_MSG_CTL *pmctl = alloc_msg_ctl();
  int rc;

  if ( pmctl == NULL )
    return NULL;


  rc = socket_init( pmctl, host );

  if ( rc < 0 )
    goto fail_free;

  comm_init( pmctl, passwd );

  #if defined( MBG_TGT_WIN32 )
    mbgextio_set_console_control_handler();
  #endif

  #if _USE_MUTEX
    _mbg_mutex_init( &pmctl->xmt.xmt_mutex );
  #endif

  goto done;

fail_free:
  dealloc_msg_ctl( &pmctl );

done:
  return pmctl;

}  // mbgextio_open_socket

#endif  // _USE_SOCKET_IO



#if _USE_SERIAL_IO

/*HDR*/
/**
 * @brief Open a binary communication channel using direct serial I/O
 *
 * See the common notes at the top of this file for details.
 *
 * @param dev       Name of the serial port to which the device is connected,
 *                  depending on the naming conventions of the target system
 * @param baud_rate Baud rate used for serial communication. Usually 19200
 * @param framing   Framing used for serial communication. Usually "8N1"
 *
 * @return A ::MBG_MSG_CTL control structure to be used with further API calls, or NULL on error
 *
 * @see mbgextio_open_socket
 * @see mbgextio_open_usb
 * @see mbgextio_close_connection
 */
_NO_MBG_API_ATTR MBG_MSG_CTL * _MBG_API mbgextio_open_serial( const char *dev,
                             uint32_t baud_rate, const char *framing )
{
  MBG_MSG_CTL *pmctl = alloc_msg_ctl();
  int rc;

  if ( pmctl == NULL )
    return NULL;


  pmctl->conn_type = MBG_CONN_TYPE_SERIAL;
  pmctl->msg_rcv_timeout = MBGEXTIO_MSG_RCV_TIMEOUT_SERIAL;
  pmctl->char_rcv_timeout = MBGEXTIO_CHAR_RCV_TIMEOUT_SERIAL;

  rc = mbgserio_open( &pmctl->st.serio, dev );

  if ( rc < 0 )
    goto fail_free;

  mbgserio_set_parms( &pmctl->st.serio, baud_rate, framing );

  #if _USE_MUTEX
    _mbg_mutex_init( &pmctl->xmt.xmt_mutex );
  #endif

  goto done;

fail_free:
  dealloc_msg_ctl( &pmctl );

done:
  return pmctl;

}  // mbgextio_open_serial

#endif



#if _USE_USB_IO

/*HDR*/
/**
 * @brief Open a binary communication channel using direct USB I/O
 *
 * See the common notes at the top of this file for details.
 *
 * @param usbdev The internal USB device to communicate with
 *
 * @return A ::MBG_MSG_CTL control structure to be used with further API calls, or NULL on error
 *
 * @see mbgextio_open_socket
 * @see mbgextio_open_serial
 * @see mbgextio_close_connection
 */
_NO_MBG_API_ATTR MBG_MSG_CTL * _MBG_API mbgextio_open_usb( const struct usb_device *usbdev )
{
  MBG_MSG_CTL *pmctl = alloc_msg_ctl();
  int rc;

  if ( pmctl == NULL )
    return NULL;


  pmctl->conn_type = MBG_CONN_TYPE_USB;
  pmctl->msg_rcv_timeout = MBGEXTIO_MSG_RCV_TIMEOUT_SERIAL;
  pmctl->char_rcv_timeout = MBGEXTIO_CHAR_RCV_TIMEOUT_SERIAL;

  pmctl->st.usbio.usbdev = usbdev;

  rc = mbg_open_usb_device_by_handle( &pmctl->st.usbio );

  if ( rc < 0 )
    goto fail_free;

  #if _USE_MUTEX
    _mbg_mutex_init( &pmctl->xmt.xmt_mutex );
  #endif

  goto done;


fail_free:
  dealloc_msg_ctl( &pmctl );

done:
  return pmctl;

}  // mbgextio_open_usb

#endif



/*HDR*/
/**
 * @brief Close a binary communication channel and release resources
 *
 * Closes a binary communication channel which has been opened by one
 * of the mbgextio_open_...() functions and releases the buffers which
 * have been allocated when the channel was opened.
 *
 * The address pointer the address of which is passed to this function
 * is set to NULL after the channel has been closed and the resources
 * have been released.
 *
 * @param ppmctl Address of a variable holding a ::MBG_MSG_CTL pointer
 *               returned when the channel was opened
 *
 * @see mbgextio_open_socket
 * @see mbgextio_open_serial
 * @see mbgextio_open_usb
 */
_NO_MBG_API_ATTR void _MBG_API mbgextio_close_connection( MBG_MSG_CTL **ppmctl )
{
  MBG_MSG_CTL *pmctl = *ppmctl;

  switch ( pmctl->conn_type )
  {
    #if _USE_SERIAL_IO
      case MBG_CONN_TYPE_SERIAL:
        mbgserio_close( &pmctl->st.serio );
        break;
    #endif  // _USE_SERIAL_IO

    #if _USE_SOCKET_IO
      case MBG_CONN_TYPE_SOCKET:
      {
        #if defined( MBG_TGT_CVI ) || defined( MBG_TGT_WIN32 )
          _close( pmctl->st.sockio.sockfd );
        #elif defined( MBG_TGT_UNIX )
          close( pmctl->st.sockio.sockfd );
        #else
          #error close socket needs to be implemented for this target
        #endif
        pmctl->st.sockio.sockfd = 0;
      } break;
    #endif  // _USE_SOCKET_IO

    #if _USE_USB_IO
      case MBG_CONN_TYPE_USB:
      {
        if ( pmctl->st.usbio.udev )
          usb_close( pmctl->st.usbio.udev );
        pmctl->st.usbio.udev = NULL;
      } break;
    #endif  // _USE_USB_IO

  }  // switch

  #if _USE_MUTEX
    _mbg_mutex_destroy( &pmctl->xmt.xmt_mutex );
  #endif

  dealloc_msg_ctl( ppmctl );

}  // mbgextio_close_connection



#if _USE_SERIAL_IO

/*HDR*/
/**
 * @brief Try to force a serial connection to a device
 *
 * A device's serial port may have been configured to work by default
 * in a way which is not appropriate for binary communication, e.g. using
 * a low communication speed, or some framing like "7E2" which messes up
 * binary data since the parity bit overrides a data bit.
 *
 * This function sends a special command to a device which lets the device
 * temporarily switch to 19200/8N1 which is usually used for binary communication.
 * Since the current settings of the device's serial port are unknown this
 * this command is sent in all common combinations of baud rates and
 * framings.
 *
 * After this function has finished it should be possible to open the
 * communication channel using mbgextio_open_serial() eith the default
 * parameters 19200/8N1.
 *
 * @param dev  Name of the serial port to which the device is connected,
 *             depending on the naming conventions of the target system
 *
 * @return  0 on success, -1 if the serial port could not be opened
 *
 * @see mbgextio_open_serial
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_force_connection( const char *dev )
{
  static const char *cmd_str = "\nDFC\n";

  int i;
  int j;
  int len = strlen( cmd_str );

  for ( i = 0; i < N_MBG_BAUD_RATES; i++ )
  {
    for ( j = 0; j < N_MBG_FRAMINGS; j++ )
    {
      uint32_t baud_rate = mbg_baud_rates[i];
      const char *framing = mbg_framing_strs[j];
      MBG_MSG_CTL *pmctl = mbgextio_open_serial( dev, baud_rate, framing );

      if ( pmctl == NULL ) // failed to open port
        return -1;

      mbgserio_write( pmctl->st.serio.port_handle, cmd_str, len );
      #ifdef MBG_TGT_WIN32
        // Flushing the output when the serial port is closed doesn't
        // always work correctly under Windows, so we insert a delay
        // here to make sure the string has been set.
        // The required delay depends on the number of characters to
        // send, and on the transmission speed (baud rate).
        Sleep( ( ( 10 * 1000 * strlen( cmd_str ) ) / baud_rate ) + 1 );
      #endif
      mbgextio_close_connection( &pmctl );
    }
  }

  return 0;

}  // mbgextio_force_connection

#endif  // _USE_SERIAL_IO



/*HDR*/
/**
 * @brief Retrieve address of the allocated receive buffer
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return Address of the allocated receive buffer
 *
 * @see mbgextio_get_rcv_buffer_size
 * @see mbgextio_get_xmt_buffer_addr
 * @see mbgextio_get_xmt_buffer_size
 */
_NO_MBG_API_ATTR MBG_MSG_BUFF * _MBG_API mbgextio_get_rcv_buffer_addr( MBG_MSG_CTL *pmctl )
{
  if ( pmctl == NULL )
    return NULL;

  return pmctl->rcv.pmb;

}  // mbgextio_get_rcv_buffer_addr



/*HDR*/
/**
 * @brief Retrieve size of the allocated receive buffer
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return Size of the allocated receive buffer
 *
 * @see mbgextio_get_rcv_buffer_addr
 * @see mbgextio_get_xmt_buffer_addr
 * @see mbgextio_get_xmt_buffer_size
 */
_NO_MBG_API_ATTR size_t _MBG_API mbgextio_get_rcv_buffer_size( MBG_MSG_CTL *pmctl )
{
  if ( pmctl == NULL )
    return 0;

  return sizeof( *pmctl->rcv.pmb );

}  // mbgextio_get_rcv_buffer_size



/*HDR*/
/**
 * @brief Retrieve address of the allocated transmit buffer
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return Address of the allocated transmit buffer
 *
 * @see mbgextio_get_rcv_buffer_addr
 * @see mbgextio_get_rcv_buffer_size
 * @see mbgextio_get_xmt_buffer_size
 */
_NO_MBG_API_ATTR MBG_MSG_BUFF * _MBG_API mbgextio_get_xmt_buffer_addr( MBG_MSG_CTL *pmctl )
{
  if ( pmctl == NULL )
    return NULL;

  return pmctl->xmt.pmb;

}  // mbgextio_get_xmt_buffer_addr



/*HDR*/
/**
 * @brief Retrieve size of the allocated transmit buffer
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return Size of the allocated transmit buffer
 *
 * @see mbgextio_get_rcv_buffer_addr
 * @see mbgextio_get_rcv_buffer_size
 * @see mbgextio_get_xmt_buffer_addr
 */
_NO_MBG_API_ATTR size_t _MBG_API mbgextio_get_xmt_buffer_size( MBG_MSG_CTL *pmctl )
{
  if ( pmctl == NULL )
    return 0;

  return sizeof( *pmctl->xmt.pmb );

}  // mbgextio_get_xmt_buffer_size



/*HDR*/
/**
 * @brief Set character receive timeout value
 *
 * @param pmctl        Pointer to a valid message control structure
 * @param new_timeout  New timeout value [ms]
 *
 * @see mbgextio_get_char_rcv_timeout
 * @see mbgextio_set_msg_rcv_timeout
 * @see mbgextio_get_msg_rcv_timeout
 */
_NO_MBG_API_ATTR void _MBG_API mbgextio_set_char_rcv_timeout( MBG_MSG_CTL *pmctl, ulong new_timeout )
{
  pmctl->char_rcv_timeout = new_timeout;

}  // mbgextio_set_char_rcv_timeout



/*HDR*/
/**
 * @brief Get character receive timeout value
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return  Current timeout value [ms]
 *
 * @see mbgextio_set_char_rcv_timeout
 * @see mbgextio_set_msg_rcv_timeout
 * @see mbgextio_get_msg_rcv_timeout
 */
_NO_MBG_API_ATTR ulong _MBG_API mbgextio_get_char_rcv_timeout( const MBG_MSG_CTL *pmctl )
{
  return pmctl->char_rcv_timeout;

}  // mbgextio_get_char_rcv_timeout



/*HDR*/
/**
 * @brief Set message receive timeout value
 *
 * @param pmctl        Pointer to a valid message control structure
 * @param new_timeout  New timeout value [ms]
 *
 * @see mbgextio_set_char_rcv_timeout
 * @see mbgextio_get_char_rcv_timeout
 * @see mbgextio_get_msg_rcv_timeout
 */
_NO_MBG_API_ATTR void _MBG_API mbgextio_set_msg_rcv_timeout( MBG_MSG_CTL *pmctl, ulong new_timeout )
{
  pmctl->msg_rcv_timeout = new_timeout;

}  // mbgextio_set_msg_rcv_timeout



/*HDR*/
/**
 * @brief Get message receive timeout value
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return  Current timeout value [ms]
 *
 * @see mbgextio_set_char_rcv_timeout
 * @see mbgextio_get_char_rcv_timeout
 * @see mbgextio_set_msg_rcv_timeout
 */
_NO_MBG_API_ATTR ulong _MBG_API mbgextio_get_msg_rcv_timeout( const MBG_MSG_CTL *pmctl )
{
  return pmctl->msg_rcv_timeout;

}  // mbgextio_get_msg_rcv_timeout



/*HDR*/
/**
 * @brief Set up and send a generic binary message
 *
 * @note This function should preferably be used only as low level function
 * called from within more specific functions used to send specific data.
 * If this function is called directly with a buffer to be sent then the
 * transmit mutex is acquired by this function. However, other (higher level)
 * API functions which set up the transmit buffer directly have to acquire
 * the transmit mutex by themselves before they set up the transmit buffer,
 * and pass a NULL pointer to indicate the transmit buffer has already been
 * set up. The correct number of bytes to send (n_bytes) has to be specified
 * anyway, though.
 *
 * @param pmctl    Pointer to a valid message control structure
 * @param cmd      One of the command codes enumerated in ::GPS_CMD_CODES
 * @param p        Address of a data structure according to the specified cmd parameter, or NULL
 * @param n_bytes  Size of the data structure addressed by parameter p
 *
 * @return  0 on success, < 0 on error //##++ @todo specify return codes
 *
 * @see mbgextio_rcv_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_req_data
 * @see mbgextio_xmt_cmd_us
 * @see mbgextio_req_data_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_xmt_msg( MBG_MSG_CTL *pmctl, GPS_CMD cmd,
                                                const void *p, size_t n_bytes )
{
  MBG_MSG_BUFF *pmb;

  if ( n_bytes > sizeof( pmb->u.msg_data ) )
    return -1;  // bytes to send exceed buffer size


  pmb = pmctl->xmt.pmb;

  if ( p )
  {
    #if _USE_MUTEX
      _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
    #endif
    memcpy( pmb->u.bytes, p, n_bytes );
  }

  pmb->hdr.len = n_bytes;
  pmb->hdr.cmd = cmd;
  xmt_tbuff( pmctl );

  #if _USE_MUTEX
    _mbg_mutex_release( &pmctl->xmt.xmt_mutex );
  #endif

  if ( cmd & GPS_REQACK )
  {
    int rc = mbgextio_rcv_msg( pmctl, (GPS_CMD) ( cmd &  ~GPS_CTRL_MSK ) );

    if ( rc != TR_COMPLETE )
      return -2;

    if ( pmctl->rcv.pmb->hdr.cmd & GPS_NACK )
      return -3;

    if ( !(pmctl->rcv.pmb->hdr.cmd & GPS_ACK) )
      return -4;
  }


  return 0;

}  // mbgextio_xmt_msg



/*HDR*/
/**
 * @brief Generic reception of a binary message
 *
 * @note A certain message type to be waited for can be specified by
 * passing one of the command codes enumerated in ::GPS_CMD_CODES.
 * If the special cmd code GPS_WILDCARD is specified the function returns
 * successfully after *any* type of binary message has been received.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES, or ::GPS_WILDCARD
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_req_data
 * @see mbgextio_xmt_cmd_us
 * @see mbgextio_req_data_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_rcv_msg( MBG_MSG_CTL *pmctl, GPS_CMD cmd )
{
  MBG_MSG_RCV_CTL *prctl;
  MBG_MSG_BUFF *pmb;
  MBG_TMO_TIME msg_timeout;
  char buff[MBGEXTIO_READ_BUFFER_SIZE];
  ssize_t n_bytes;
  int rc;
  int i;

  mbg_tmo_set_timeout_ms( &msg_timeout, pmctl->msg_rcv_timeout );

  for (;;)  // loop until complete msg received
  {
    n_bytes = 0;

    if ( mbg_tmo_curr_time_is_after( &msg_timeout ) )
      return TR_TIMEOUT;

    #if _USE_SOCKET_IO
      if ( pmctl->conn_type == MBG_CONN_TYPE_SOCKET )
      {
        struct timeval tv_timeout;
        fd_set fds;

        if ( pmctl->io_error )
          return TR_IO_ERR;

        mbgserio_msec_to_timeval( pmctl->msg_rcv_timeout, &tv_timeout );

        FD_ZERO( &fds );
        FD_SET( pmctl->st.sockio.sockfd, &fds );

        rc = select( pmctl->st.sockio.sockfd + 1, &fds, NULL, NULL, &tv_timeout );

        if ( rc == 0 )    // timeout
          return TR_TIMEOUT;

        if ( rc < 0 )     // error
        {
          pmctl->io_error = 1;
          return TR_IO_ERR;
        }

        // data is available

        n_bytes = recv( pmctl->st.sockio.sockfd, buff, sizeof( buff ), 0 );

        if ( n_bytes < 0 )
        {
          pmctl->io_error = 1;
          return TR_IO_ERR;
        }
      }
    #endif  // _USE_SOCKET_IO

    #if _USE_SERIAL_IO
      if ( pmctl->conn_type == MBG_CONN_TYPE_SERIAL )
      {
        n_bytes = mbgserio_read_wait( pmctl->st.serio.port_handle, &buff[0],
                                      sizeof( buff[0] ), pmctl->char_rcv_timeout );

        if ( n_bytes < 0 )
        {
          if ( n_bytes == MBGSERIO_TIMEOUT )
             return TR_TIMEOUT;

          pmctl->io_error = 1;
          return TR_IO_ERR;
        }
      }
    #endif  // _USE_SERIAL_IO

    #if _USE_USB_IO
      if ( pmctl->conn_type == MBG_CONN_TYPE_USB )
      {
        if ( pmctl->io_error )
          return TR_IO_ERR;

        rc = mbg_usb_read( pmctl->st.usbio.udev, 0x81, (uint8_t*) buff, 512, 1000 );

        if ( rc == -110 )    // libusb: timeout
          return TR_TIMEOUT;

        if ( rc < 0 )     // error
        {
          pmctl->io_error = 1;
          return TR_IO_ERR;
        }

        // data is available

        n_bytes = rc;

      }
    #endif  // _USE_USB_IO

    prctl = &pmctl->rcv;
    pmb = prctl->pmb;

    for ( i = 0; i < n_bytes; i++ )
    {
      char c = buff[i];

      /* check if the new char belongs to a data transfer sequence */
      rc = check_transfer( prctl, c );

      switch ( rc )
      {
        case TR_WAITING:      /* no data transfer sequence in progress */
          #if _USE_CHK_TSTR
            if ( prctl->chk_tstr_fnc )  /* optionally handle normal, non-protocol data */
            {
              int tstr_rc = prctl->chk_tstr_fnc( c, prctl->chk_tstr_arg );

              if ( tstr_rc > 0 )  // a valid time string has been received
              {
                // return only if the caller does not wait for a specific packet type
                if ( cmd == GPS_WILDCARD )
                  return TR_COMPLETE_TSTR;
              }
            }
          #endif
          // intentional fall-through

        case TR_RECEIVING:    /* data transfer sequence in progress, keep waiting */
          continue;

        case TR_COMPLETE:
          {
            GPS_CMD rcvd_cmd;

            #if _USE_CHK_TSTR
              //##+++++++++++++++++
              // If a valid binary packet has been received then discard
              // a partial time string possibly received before.
            #endif

            rcvd_cmd = pmb->hdr.cmd & ~GPS_CTRL_MSK;

            if ( rcvd_cmd == cmd )  /* the received packet is what we've been waiting for */
            {
              if ( pmb->hdr.cmd & GPS_NACK )
                return TR_RCVD_NACK;

              return TR_COMPLETE;
            }

            #if _USE_ENCRYPTION
              /* if an encrypted packet has been received then decrypt it */
              if ( rcvd_cmd == GPS_CRYPTED_PACKET )
              {
                rc = decrypt_message( pmctl );

                if ( rc < 0 )  /* decryption error */
                  return rc;

                rcvd_cmd = pmb->hdr.cmd & ~GPS_CTRL_MSK;

                if ( rcvd_cmd == cmd )  /* the received packet is what we've been waiting for */
                  return TR_COMPLETE;
              }
            #endif

            /* not waiting  for a specific packet, so return if any packet is complete */
            if ( cmd == GPS_WILDCARD )
              return TR_COMPLETE;

            //##++ received a msg which does not match the expected code
            prctl->cnt = 0;      /* restart receiving */
          }
          break;

        default:    /* any error condition */
          return rc;

      }  /* switch */
    }
  }

}  // mbgextio_rcv_msg



/*HDR*/
/**
 * @brief Transmit a command-only message without additional data.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_rcv_msg
 * @see mbgextio_req_data
 * @see mbgextio_xmt_cmd_us
 * @see mbgextio_req_data_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_xmt_cmd( MBG_MSG_CTL *pmctl, GPS_CMD cmd )
{
  int rc;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  rc = xmt_cmd( pmctl, cmd );

  #if _USE_MUTEX
    _mbg_mutex_release( &pmctl->xmt.xmt_mutex );
  #endif

  return rc;

}  // mbgextio_xmt_cmd



/*HDR*/
/**
 * @brief Transmit a message without a single ushort (16 bit) parameter
 *
 * The ushort parameter is often used to send an index value when requesting
 * a certain element of an array of same data structures.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES
 * @param us     The parameter for the command code
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_rcv_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_req_data
 * @see mbgextio_req_data_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_xmt_cmd_us( MBG_MSG_CTL *pmctl, GPS_CMD cmd, uint16_t us )
{
  int rc;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  rc = xmt_cmd_us( pmctl, cmd, us );

  #if _USE_MUTEX
    _mbg_mutex_release( &pmctl->xmt.xmt_mutex );
  #endif

  return rc;

}  // mbgextio_xmt_cmd_us



/*HDR*/
/**
 * @brief Transmit a message without a single ushort (16 bit) parameter
 *
 * The ushort parameter is often used to send an index value when requesting
 * a specific element of an array of data structures.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_rcv_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_xmt_cmd_us
 * @see mbgextio_req_data_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_req_data( MBG_MSG_CTL *pmctl, GPS_CMD cmd )
{
  xmt_cmd( pmctl, cmd );   /* request a set of data */

  return mbgextio_rcv_msg( pmctl, cmd );

}  // mbgextio_req_data



/*HDR*/
/**
 * @brief Read a specific element of an array of data structures
 *
 * The type of data is implicitely associated to the cmd parameter.
 * Usually the number of supported array elements has to be determined
 * by some other means, e.g. from a field in the ::RECEIVER_INFO structure.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES
 * @param idx    The index of the array element to read
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_rcv_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_req_data
 * @see mbgextio_xmt_cmd_us
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_req_data_idx( MBG_MSG_CTL *pmctl, GPS_CMD cmd, uint16_t idx )
{
  xmt_cmd_us( pmctl, cmd, idx );           // send a request for a set of data

  return mbgextio_rcv_msg( pmctl, cmd );   // wait for the reply

}  // mbgextio_req_data_idx



/*HDR*/
/**
 * @brief Read a receiver info structure
 *
 * The ::RECEIVER_INFO should be read at first to identify the connected
 * device and determine the basic features supported by thr device.
 *
 * @note Some very old devices may not provide a ::RECEIVER_INFO,
 * so mbgextio_setup_receiver_info() should be called preferably
 * to read the receiver info usin this function, if supported,
 * or set up a default structure for devices which don't provide
 * a receiver info.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_setup_receiver_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_receiver_info( MBG_MSG_CTL *pmctl, RECEIVER_INFO *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_RECEIVER_INFO );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.receiver_info;
    _mbg_swab_receiver_info( p );
  }

  return rc;

}  // mbgextio_get_receiver_info



/*HDR*/
/**
 * @brief Read a receiver info structure
 *
 * The ::RECEIVER_INFO should be read at first to identify the connected
 * device and determine the basic features supported by thr device.
 *
 * @note Some very old devices may not provide a ::RECEIVER_INFO.
 * This function tries to read the ::RECEIVER_INFO from the device,
 * and sets up a default structure if the device doesn't support this.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_receiver_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_setup_receiver_info( MBG_MSG_CTL *pmctl, RECEIVER_INFO *p )
{
  int rc = mbgextio_get_receiver_info( pmctl, p );

  if ( rc == TR_COMPLETE )
  {
    if ( p )
    {
      *p = pmctl->rcv.pmb->u.msg_data.receiver_info;
      _mbg_swab_receiver_info( p );
    }

    return rc;
  }

  //##++++ TODO try to read SW_REV, etc.

  return -11;  //##+++++++++++

}  // mbgextio_setup_receiver_info



/*HDR*/
/**
 * @brief Read the software revision (obsolete)
 *
 * @note This function is obsolete since the ::SW_REV structure is also
 * a field included in the ::RECEIVER_INFO. This call may be required,
 * though, for very old devices which don't support the ::RECEIVER_INFO.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_setup_receiver_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_sw_rev( MBG_MSG_CTL *pmctl, SW_REV *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_SW_REV );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.sw_rev;
    _mbg_swab_sw_rev( p );
  }

  return rc;

}  // mbgextio_get_sw_rev



/*HDR*/
/**
 * @brief Read the status of buffered variables
 *
 * @note This function is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_bvar_stat( MBG_MSG_CTL *pmctl, BVAR_STAT *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_BVAR_STAT );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.bvar_stat;
    _mbg_swab_bvar_stat( p );
  }

  return rc;

}  // mbgextio_get_bvar_stat



/*HDR*/
/**
 * @brief Read the current time as ::TTM strucure
 *
 * @note This function is only supported by GPS receivers.
 *
 * The returned time is not very accurate since the response time
 * transmission delay can't be determmined.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_time( MBG_MSG_CTL *pmctl, TTM *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_TIME );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.ttm;
    _mbg_swab_ttm( p );
  }

  return rc;

}  // mbgextio_get_time



/*HDR*/
/**
 * @brief Set the device's time by sending a ::TTM strucure
 *
 * @note The function is not supported by all devices. Time has to be
 * passed as local time according to the device's ::TZDL settings.
 * New time is only set with some tens of ms accuracy.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_time( MBG_MSG_CTL *pmctl, const TTM *p )
{
  GPS_CMD cmd = GPS_TIME | OPT_GPS_ACK_CODE;
  TTM *p_data = &pmctl->xmt.pmb->u.msg_data.ttm;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_ttm( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_time



/*HDR*/
/**
 * @brief Read the current receiver position as ::LLA strucure
 *
 * @note This function is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param lla    Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_pos_lla( MBG_MSG_CTL *pmctl, LLA lla )
{
  int rc = mbgextio_req_data( pmctl, GPS_POS_LLA );

  if ( ( rc == TR_COMPLETE ) && lla )
  {
    MSG_DATA *pmb = &pmctl->rcv.pmb->u.msg_data;
    int i;

    for ( i = 0; i < N_LLA; i++ )
    {
      swap_double( &pmb->lla[i] );
      lla[i] = pmb->lla[i];
    }
  }

  return rc;

}  // mbgextio_get_pos_lla



/*HDR*/
/**
 * @brief Set the device's position by sending an ::LLA strucure
 *
 * @note This function is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param lla    Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_pos_lla( MBG_MSG_CTL *pmctl, const LLA lla )
{
  GPS_CMD cmd = GPS_POS_LLA | OPT_GPS_ACK_CODE;
  double *p_lla = pmctl->xmt.pmb->u.msg_data.lla;
  int i;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  for ( i = 0; i < N_LLA; i++ )
  {
    p_lla[i] = lla[i];
    swap_double( &p_lla[i] );
    _mbg_swab_double( &p_lla[i] );
  }

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( LLA ) );

}  // mbgextio_set_pos_lla



/*HDR*/
/**
 * @brief Read the local time conversion parameters in ::TZDL format
 *
 * @note Some devices may not support ::TZDL settings
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_tzdl( MBG_MSG_CTL *pmctl, TZDL *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_TZDL );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.tzdl;
    _mbg_swab_tzdl( p );
  }

  return rc;

}  // mbgextio_get_tzdl



/*HDR*/
/**
 * @brief Set the local time conversion parameters in ::TZDL format
 *
 * @note Some devices may not support ::TZDL settings
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_tzdl( MBG_MSG_CTL *pmctl, const TZDL *p )
{
  GPS_CMD cmd = GPS_TZDL | OPT_GPS_ACK_CODE;
  TZDL *p_data = &pmctl->xmt.pmb->u.msg_data.tzdl;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_tzdl( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_tzdl



/*HDR*/
/**
 * @brief Read serial port parameters in ::PORT_PARM format
 *
 * @deprecated This function is deprecated since the ::PORT_PARM structure
 * supports only 2 serial ports, does not not support configuration
 * of a string type. The function mbgextio_get_serial_settings() should
 * be used instead.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_serial_settings
 * @see mbgextio_save_serial_settings
 * @see mbgextio_set_port_parm
 * @see mbgextio_setup_receiver_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_port_parm( MBG_MSG_CTL *pmctl, PORT_PARM *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_PORT_PARM );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.port_parm;
    _mbg_swab_port_parm( p );
  }

  return rc;

}  // mbgextio_get_port_parm



 /*HDR*/
/**
 * @brief Send serial port parameters in ::PORT_PARM format
 *
 * @deprecated This function is deprecated since the ::PORT_PARM structure
 * supports only 2 serial ports, does not not support configuration
 * of a string type. The function mbgextio_save_serial_settings() should
 * be used instead.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_serial_settings
 * @see mbgextio_save_serial_settings
 * @see mbgextio_get_port_parm
 * @see mbgextio_setup_receiver_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_port_parm( MBG_MSG_CTL *pmctl, const PORT_PARM *p )
{
  GPS_CMD cmd = GPS_PORT_PARM | OPT_GPS_ACK_CODE;
  PORT_PARM *p_data = &pmctl->xmt.pmb->u.msg_data.port_parm;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_port_parm( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_port_parm



/*HDR*/
/**
 * @brief Read the frequency synthesizer settings
 *
 * @note Some devices may not provide a frequency synthesizer
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_synth
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_synth( MBG_MSG_CTL *pmctl, SYNTH *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_SYNTH );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.synth;
    _mbg_swab_synth( p );
  }

  return rc;

}  // mbgextio_get_synth



/*HDR*/
/**
 * @brief Write the frequency synthesizer settings
 *
 * @note Some devices may not provide a frequency synthesizer
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_synth
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_synth( MBG_MSG_CTL *pmctl, const SYNTH *p )
{
  GPS_CMD cmd = GPS_SYNTH | OPT_GPS_ACK_CODE;
  SYNTH *p_data = &pmctl->xmt.pmb->u.msg_data.synth;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_synth( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_synth



/*HDR*/
/**
 * @brief Read the GPS antenna info structure
 *
 * @note This is only supported by GPS receivers.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_ant_info( MBG_MSG_CTL *pmctl, ANT_INFO *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_ANT_INFO );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.ant_info;
    _mbg_swab_ant_info( p );
  }

  return rc;

}  // mbgextio_get_ant_info



/*HDR*/
/**
 * @brief Read a user capture event in ::TTM format
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_clr_ucap_buff
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_ucap( MBG_MSG_CTL *pmctl, TTM *p )
{
  int rc;

  xmt_cmd( pmctl, GPS_UCAP );   /* request a set of data */

  // Attention: Older firmware versions may reply with GPS_TIME
  // messages instead of GPS_UCAP messages, and may not send a reply
  // at all if no capture event is available in the on-board FIFO.
  for (;;)
  {
    rc = mbgextio_rcv_msg( pmctl, -1 );

    if ( rc < 0 )
      break;

    if ( rc != TR_COMPLETE )
      continue;

    if ( pmctl->rcv.pmb->hdr.cmd == GPS_UCAP )
      break;

    if ( pmctl->rcv.pmb->hdr.cmd == GPS_TIME )
      if ( pmctl->rcv.pmb->hdr.len > 0 )
        if ( pmctl->rcv.pmb->u.msg_data.ttm.channel >= 0 )
          break;
  }

  if ( p )
  {
    // If the length of the msg header is 0 then the capture buffer
    // is empty. This is indicated with 0xFF in the seconds field of
    // the GPS time structure.
    if ( pmctl->rcv.pmb->hdr.len > 0 )
      *p = pmctl->rcv.pmb->u.msg_data.ttm;
    else
      _ttm_time_set_unavail( p );  // no capture event available
  }

  return rc;

}  // mbgextio_get_ucap



/*HDR*/
/**
 * @brief Read the enable flags controlling when output signals are enabled
 *
 * @note Some devices may not support ::ENABLE_FLAGS
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_enable_flags
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_enable_flags( MBG_MSG_CTL *pmctl, ENABLE_FLAGS *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_ENABLE_FLAGS );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.enable_flags;
    _mbg_swab_enable_flags( p );
  }

  return rc;

}  // mbgextio_get_enable_flags



/*HDR*/
/**
 * @brief Send the enable flags controlling when output signals are enabled
 *
 * @note Some devices may not support ::ENABLE_FLAGS
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_enable_flags
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_enable_flags( MBG_MSG_CTL *pmctl, const ENABLE_FLAGS *p )
{
  GPS_CMD cmd = GPS_ENABLE_FLAGS | OPT_GPS_ACK_CODE;
  ENABLE_FLAGS *p_data = &pmctl->xmt.pmb->u.msg_data.enable_flags;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_enable_flags( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_enable_flags



/*HDR*/
/**
 * @brief Read GPS status info
 *
 * @note This is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_stat_info( MBG_MSG_CTL *pmctl, STAT_INFO *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_STAT_INFO );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.stat_info;
    _mbg_swab_stat_info( p );
  }

  return rc;

}  // mbgextio_get_stat_info



/*HDR*/
/**
 * @brief Read the configured length of the GPS antenna cable
 *
 * @note This is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_ant_cable_len
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_ant_cable_len( MBG_MSG_CTL *pmctl, ANT_CABLE_LEN *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_ANT_CABLE_LENGTH );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.ant_cable_len;
    _mbg_swab_ant_cable_len( p );
  }

  return rc;

}  // mbgextio_get_ant_cable_len



/*HDR*/
/**
 * @brief Send the GPS antenna cable length configuration
 *
 * @note This is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_ant_cable_len
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_ant_cable_len( MBG_MSG_CTL *pmctl, const ANT_CABLE_LEN *p )
{
  GPS_CMD cmd = GPS_ANT_CABLE_LENGTH | OPT_GPS_ACK_CODE;
  ANT_CABLE_LEN *p_data = &pmctl->xmt.pmb->u.msg_data.ant_cable_len;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_ant_cable_len( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_ant_cable_len



/*HDR*/
/**
 * @brief Read configuration info and supported features for the device's IRIG output
 *
 * @note This is only supported if GPS_HAS_IRIG_TX is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_irig_tx_settings
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_irig_tx_info( MBG_MSG_CTL *pmctl, IRIG_INFO *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_IRIG_TX_INFO );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.irig_tx_info;
    _mbg_swab_irig_info( p );
  }

  return rc;

}  // mbgextio_get_irig_tx_info



/*HDR*/
/**
 * @brief Send new configuration settings for the device's IRIG output
 *
 * @note This is only supported if GPS_HAS_IRIG_TX is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_irig_tx_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_irig_tx_settings( MBG_MSG_CTL *pmctl, const IRIG_SETTINGS *p )
{
  GPS_CMD cmd = GPS_IRIG_TX_SETTINGS | OPT_GPS_ACK_CODE;
  IRIG_SETTINGS *p_data = &pmctl->xmt.pmb->u.msg_data.irig_tx_settings;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_irig_settings( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_irig_tx_settings



/*HDR*/
/**
 * @brief Read configuration info and supported features for the device's IRIG input
 *
 * @note This is only supported if GPS_HAS_IRIG_RX is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_irig_rx_settings
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_irig_rx_info( MBG_MSG_CTL *pmctl, IRIG_INFO *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_IRIG_RX_INFO );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.irig_rx_info;
    _mbg_swab_irig_info( p );
  }

  return rc;

}  // mbgextio_get_irig_rx_info



/*HDR*/
/**
 * @brief Send new configuration settings for the device's IRIG input
 *
 * @note This is only supported if GPS_HAS_IRIG_RX is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_irig_rx_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_irig_rx_settings( MBG_MSG_CTL *pmctl, const IRIG_SETTINGS *p )
{
  GPS_CMD cmd = GPS_IRIG_RX_SETTINGS | OPT_GPS_ACK_CODE;
  IRIG_SETTINGS *p_data = &pmctl->xmt.pmb->u.msg_data.irig_rx_settings;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_irig_settings( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_irig_rx_settings



/*HDR*/
/**
 * @brief Read current ref offset to %UTC configuration
 *
 * @note This is only supported if GPS_HAS_REF_OFFS is set in RECEIVER_INFO::features,
 * usually with IRIG receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_ref_offs
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_ref_offs( MBG_MSG_CTL *pmctl, MBG_REF_OFFS *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_REF_OFFS );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.ref_offs;
    _mbg_swab_mbg_ref_offs( p );
  }

  return rc;

}  // mbgextio_get_ref_offs



/*HDR*/
/**
 * @brief Send new ref offset to %UTC settings
 *
 * @note This is only supported if GPS_HAS_REF_OFFS is set in RECEIVER_INFO::features,
 * usually with IRIG receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_ref_offs
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_ref_offs( MBG_MSG_CTL *pmctl, const MBG_REF_OFFS *p )
{
  GPS_CMD cmd = GPS_REF_OFFS | OPT_GPS_ACK_CODE;
  MBG_REF_OFFS *p_data = &pmctl->xmt.pmb->u.msg_data.ref_offs;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_mbg_ref_offs( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_ref_offs



/*HDR*/
/**
 * @brief Read current debug status
 *
 * @note This is only supported if GPS_HAS_DEBUG_STATUS is set in RECEIVER_INFO::features,
 * usually with IRIG receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_debug_status( MBG_MSG_CTL *pmctl, MBG_DEBUG_STATUS *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_DEBUG_STATUS );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.debug_status;
    _mbg_swab_debug_status( p );
  }

  return rc;

}  // mbgextio_get_debug_status



/*HDR*/
/**
 * @brief Read current optional settings and supported options
 *
 * @note This is only supported if GPS_HAS_OPT_SETTINGS is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_opt_settings
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_opt_info( MBG_MSG_CTL *pmctl, MBG_OPT_INFO *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_OPT_INFO );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.opt_info;
    _mbg_swab_mbg_opt_info( p );
  }

  return rc;

}  // mbgextio_get_opt_info



/*HDR*/
/**
 * @brief Send new optional settings flags
 *
 * @note This is only supported if GPS_HAS_OPT_SETTINGS is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_opt_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_opt_settings( MBG_MSG_CTL *pmctl, const MBG_OPT_SETTINGS *p )
{
  GPS_CMD cmd = GPS_OPT_SETTINGS | OPT_GPS_ACK_CODE;
  MBG_OPT_SETTINGS *p_data = &pmctl->xmt.pmb->u.msg_data.opt_settings;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_mbg_opt_settings( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_opt_settings



/*HDR*/
/**
 * @brief Read information on a specific supported string format
 *
 * Retrieve a single entry from an array of supported string types.
 * The number of supported string types is available in RECEIVER_INFO::n_str_type.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 * @param idx    Index of the array element to be retrieved, 0..RECEIVER_INFO::n_str_type - 1
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_all_str_type_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_str_type_info_idx( MBG_MSG_CTL *pmctl,
                             STR_TYPE_INFO_IDX *p, uint16_t idx )
{
  int rc;

  xmt_cmd_us( pmctl, GPS_STR_TYPE_INFO_IDX, idx );

  rc = mbgextio_rcv_msg( pmctl, GPS_STR_TYPE_INFO_IDX );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.str_type_info_idx;

  #if 0  //##++ TODO: check if received idx matches requested idx
    if ( pii.idx != i )
    {
      printf( "** Info for port %i requested, but for %i received.\n",
              pii.idx, i );
      rc = ...;
    }
  #endif
  }

  return rc;

}  // mbgextio_get_str_type_info_idx



/*HDR*/
/**
 * @brief Read an array of all supported string types
 *
 * The number of supported string types is available in RECEIVER_INFO::n_str_type.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param stii   An array which can hold at least RECEIVER_INFO::n_str_type entries
 * @param p_ri   Pointer to a valid ::RECEIVER_INFO structure
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_str_type_info_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_all_str_type_info( MBG_MSG_CTL *pmctl,
                              STR_TYPE_INFO_IDX stii[],
                              const RECEIVER_INFO *p_ri )
{
  int rc = TR_COMPLETE;
  uint16_t i;

  for ( i = 0; i < p_ri->n_str_type; i++ )
  {
    rc = mbgextio_get_str_type_info_idx( pmctl, &stii[i], i );

    if ( rc < 0 )
      break;
  }

  return rc;

}  // mbgextio_get_all_str_type_info



/*HDR*/
/**
 * @brief Read current settings and capabilities of a specific serial port
 *
 * The number of serial ports provided by the device is available in RECEIVER_INFO::n_com_ports.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 * @param idx    Index of the array element to be retrieved, 0..RECEIVER_INFO::n_com_ports - 1
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_all_port_info
 * @see mbgextio_set_port_settings_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_port_info_idx( MBG_MSG_CTL *pmctl,
                             PORT_INFO_IDX *p, uint16_t idx )
{
  int rc;

  xmt_cmd_us( pmctl, GPS_PORT_INFO_IDX, idx );

  rc = mbgextio_rcv_msg( pmctl, GPS_PORT_INFO_IDX );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.port_info_idx;
  #if 0  //##++ TODO: check if received idx matches requested idx
    if ( pii.idx != i )
    {
      printf( "** Info for port %i requested, but for %i received.\n",
              pii.idx, i );
      rc = ...;
    }
  #endif
  }

  return rc;

}  // mbgextio_get_port_info_idx



/*HDR*/
/**
 * @brief Read an array of current settings and capabilities of all serial ports
 *
 * The number of serial ports provided by the device is available in RECEIVER_INFO::n_com_ports.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param pii    An array which can hold at least RECEIVER_INFO::n_com_ports entries
 * @param p_ri   Pointer to a valid ::RECEIVER_INFO structure
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_port_info_idx
 * @see mbgextio_set_port_settings_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_all_port_info( MBG_MSG_CTL *pmctl,
                              PORT_INFO_IDX pii[],
                              const RECEIVER_INFO *p_ri )
{
  int rc = TR_COMPLETE;
  uint16_t i;

  for ( i = 0; i < p_ri->n_com_ports; i++ )
  {
    rc = mbgextio_get_port_info_idx( pmctl, &pii[i], i );

    if ( rc < 0 )
      break;
  }

  return rc;

}  // mbgextio_get_all_port_info



/*HDR*/
/**
 * @brief Send configuration settings for a specific serial port
 *
 * The number of serial ports provided by the device is available in RECEIVER_INFO::n_com_ports.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 * @param idx    Index of the serial port to be configured, 0..RECEIVER_INFO::n_com_ports - 1
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_port_info_idx
 * @see mbgextio_get_all_port_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_port_settings_idx( MBG_MSG_CTL *pmctl,
                             const PORT_SETTINGS *p, uint16_t idx )
{
  GPS_CMD cmd = GPS_PORT_SETTINGS_IDX | OPT_GPS_ACK_CODE;
  PORT_SETTINGS_IDX *p_data = &pmctl->xmt.pmb->u.msg_data.port_settings_idx;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  p_data->port_settings = *p;
  p_data->idx = idx;
  _mbg_swab_port_settings_idx( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_port_settings_idx



/*HDR*/
/**
 * @brief Read current settings and capabilities of a specific programmable pulse output
 *
 * The number of supported pulse outputs is available in RECEIVER_INFO::n_prg_out.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 * @param idx    Index of the array element to be retrieved, 0..RECEIVER_INFO::n_prg_out - 1
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_all_pout_info
 * @see mbgextio_set_pout_settings_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_pout_info_idx( MBG_MSG_CTL *pmctl,
                             POUT_INFO_IDX *p, uint16_t idx )
{
  int rc = mbgextio_req_data_idx( pmctl, GPS_POUT_INFO_IDX, idx );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.pout_info_idx;
    _mbg_swab_pout_info_idx_on_get( p );
  #if 0  //##++ TODO: check if received idx matches requested idx
    if ( pii.idx != i )
    {
      printf( "** Info for port %i requested, but for %i received.\n",
              pii.idx, i );
      rc = ...;
    }
  #endif
  }

  return rc;

}  // mbgextio_get_pout_info_idx



/*HDR*/
/**
 * @brief Read an array of current settings and capabilities of all programmable pulse outputs
 *
 * The number of supported pulse outputs is available in RECEIVER_INFO::n_prg_out.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param pii    An array which can hold at least RECEIVER_INFO::n_prg_out entries
 * @param p_ri   Pointer to a valid ::RECEIVER_INFO structure
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_pout_info_idx
 * @see mbgextio_set_pout_settings_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_all_pout_info( MBG_MSG_CTL *pmctl, POUT_INFO_IDX *pii,
                                                          const RECEIVER_INFO *p_ri )
{
  int rc = -1; //##++
  uint16_t i;

  memset( pii, 0, p_ri->n_prg_out * sizeof( *pii ) );

  for ( i = 0; i < p_ri->n_prg_out; i++ )
  {
    rc = mbgextio_get_pout_info_idx( pmctl, &pii[i], i );

    if ( rc != TR_COMPLETE )
      break;
  }

  return rc;  // success

}  // mbgextio_get_all_pout_info



/*HDR*/
/**
 * @brief Send configuration settings for a specific programmable pulse output
 *
 * The number of supported pulse outputs is available in RECEIVER_INFO::n_prg_out.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 * @param idx    Index of the pulse output to be configured, 0..RECEIVER_INFO::n_prg_out - 1
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_pout_info_idx
 * @see mbgextio_get_all_pout_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_pout_settings_idx( MBG_MSG_CTL *pmctl,
                             const POUT_SETTINGS *p, uint16_t idx )
{
  GPS_CMD cmd = GPS_POUT_SETTINGS_IDX | OPT_GPS_ACK_CODE;
  POUT_SETTINGS_IDX *p_data = &pmctl->xmt.pmb->u.msg_data.pout_settings_idx;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  p_data->pout_settings = *p;
  p_data->idx = idx;
  _mbg_swab_pout_settings_idx_on_set( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_pout_settings_idx



/*HDR*/
/**
 * @brief Clear the user capture event buffer on-board the device
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_ucap
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_clr_ucap_buff( MBG_MSG_CTL *pmctl )
{
  return mbgextio_xmt_cmd( pmctl, GPS_CLR_UCAP_BUFF );

}  // mbgextio_clr_ucap_buff



/*HDR*/
/**
 * @brief Read time scale configuration parameters
 *
 * @note Some devices may not support a configurable time scale
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_time_scale_settings
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_time_scale_info( MBG_MSG_CTL *pmctl,
                                                         MBG_TIME_SCALE_INFO *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_TIME_SCALE );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.time_scale_info;
    _mbg_swab_mbg_time_scale_info( p );
  }

  return rc;

}  // mbgextio_get_time_scale_info



/*HDR*/
/**
 * @brief Send new time scale configuration settings
 *
 * @note Some devices may not support a configurable time scale
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_time_scale_info
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_time_scale_settings( MBG_MSG_CTL *pmctl,
                             const MBG_TIME_SCALE_SETTINGS *p )
{
  GPS_CMD cmd = GPS_TIME_SCALE | OPT_GPS_ACK_CODE;
  MBG_TIME_SCALE_SETTINGS *p_data = &pmctl->xmt.pmb->u.msg_data.time_scale_settings;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_mbg_time_scale_settings( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_time_scale_settings



/*HDR*/
/**
 * @brief Clear the on-board event log
 *
 * @note Some devices don't provide an on-board event log
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_num_evt_log_entries
 * @see mbgextio_get_first_evt_log_entry
 * @see mbgextio_get_next_evt_log_entry
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_clr_evt_log( MBG_MSG_CTL *pmctl )
{
  return mbgextio_xmt_cmd( pmctl, GPS_CLR_EVT_LOG );

}  // mbgextio_clr_evt_log



/*HDR*/
/**
 * @brief Read the current number of entries in the on-board event log
 *
 * @note Some devices don't provide an on-board event log
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_clr_evt_log
 * @see mbgextio_get_first_evt_log_entry
 * @see mbgextio_get_next_evt_log_entry
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_num_evt_log_entries( MBG_MSG_CTL *pmctl,
                                                         MBG_NUM_EVT_LOG_ENTRIES *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_NUM_EVT_LOG_ENTRIES );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.num_evt_log_entries;
    _mbg_swab_mbg_num_evt_log_entries( p );
  }

  return rc;

}  // mbgextio_get_num_evt_log_entries



/*HDR*/
/**
 * @brief Return the first entry from the on-board event log
 *
 * This resets an internal counter, so subsequent calls to
 * mbgextio_get_next_evt_log_entry() will retrieve the following entries.
 *
 * @note Some devices don't provide an on-board event log
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_clr_evt_log
 * @see mbgextio_get_num_evt_log_entries
 * @see mbgextio_get_next_evt_log_entry
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_first_evt_log_entry( MBG_MSG_CTL *pmctl, MBG_EVT_LOG_ENTRY *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_FIRST_EVT_LOG_ENTRY );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.evt_log_entry;
    _mbg_swab_mbg_evt_log_entry( p );
  }

  return rc;

}  // mbgextio_get_first_evt_log_entry



/*HDR*/
/**
 * @brief Return the next entry from the on-board event log
 *
 * This increments an internal counter, so subsequent calls will
 * return subsequent entries. mbgextio_get_first_evt_log_entry()
 * should be called first to reset the counter and retrieve the
 * oldest log entry.
 *
 * @note Some devices don't provide an on-board event log
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_clr_evt_log
 * @see mbgextio_get_num_evt_log_entries
 * @see mbgextio_get_first_evt_log_entry
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_next_evt_log_entry( MBG_MSG_CTL *pmctl, MBG_EVT_LOG_ENTRY *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_NEXT_EVT_LOG_ENTRY );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.evt_log_entry;
    _mbg_swab_mbg_evt_log_entry( p );
  }

  return rc;

}  // mbgextio_get_next_evt_log_entry



/*HDR*/
/**
 * @brief Read the current IMS state and supported IMS features
 *
 * @note This is only supported if GPS_HAS_IMS is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_ims_sensor_state_idx
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_ims_state( MBG_MSG_CTL *pmctl, MBG_IMS_STATE *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_IMS_STATE );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.ims_state;
    _mbg_swab_mbg_ims_state( p );
  }

  return rc;

}  // mbgextio_get_ims_state



/*HDR*/
/**
 * @brief Read sensor values from a specified sensor on the device
 *
 * Info on supported sensors can be retrieved using mbgextio_get_ims_state().
 * Valid range for the sensor index is [0..MBG_IMS_STATE::num_sensors - 1].
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 * @param idx    The index of the array element to read
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_ims_state
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_ims_sensor_state_idx( MBG_MSG_CTL *pmctl,
                              MBG_IMS_SENSOR_STATE_IDX *p, uint16_t idx )
{
  int rc = mbgextio_req_data_idx( pmctl, GPS_IMS_SENSOR_STATE_IDX, idx );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.ims_sensor_state_idx;
    _mbg_swab_mbg_ims_sensor_state_idx( p );
  }

  return rc;

}  // mbgextio_get_ims_sensor_state_idx



/*HDR*/
/**
 * @brief Set the XMR holdover interval
 *
 * @todo In which case is this supported?
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_holdover_interval_counter
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_holdover_interval( MBG_MSG_CTL *pmctl,
                                                              const XMR_HOLDOVER_INTV *p )
{
  GPS_CMD cmd = GPS_XMR_HOLDOVER_INTV | OPT_GPS_ACK_CODE;
  XMR_HOLDOVER_INTV *p_data = &pmctl->xmt.pmb->u.msg_data.xmr_holdover_intv;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  _mbg_swab_mbg_time_scale_settings( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_set_holdover_interval



/*HDR*/
/**
 * @brief Read the XMR holdover interval counter
 *
 * @todo In which case is this supported?
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_holdover_interval
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_holdover_interval_counter( MBG_MSG_CTL *pmctl,
                              XMR_HOLDOVER_INTV *p )
{
  int rc = mbgextio_req_data( pmctl, GPS_XMR_HOLDOVER_INTV );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.xmr_holdover_intv;
  }

  return rc;

}  // mbgextio_get_holdover_interval_counter



/*HDR*/
/**
 * @brief Read the local time conversion configuration ::TZCODE format
 *
 * @note Some devices may not support ::TZCODE configuration
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_tzcode
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_get_tzcode( MBG_MSG_CTL *pmctl, TZCODE *p )
{
  int rc = mbgextio_req_data( pmctl, PZF_TZCODE );

  if ( ( rc == TR_COMPLETE ) && p )
  {
    *p = pmctl->rcv.pmb->u.msg_data.tzcode;
    //##++++++ _mbg_swab_tzcode( p );
  }

  return rc;

}  // mbgextio_get_tzcode



/*HDR*/
/**
 * @brief Set the local time conversion configuration in ::TZCODE format
 *
 * @note Some devices may not support ::TZCODE configuration
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_tzcode
 */
_NO_MBG_API_ATTR int _MBG_API mbgextio_set_tzcode( MBG_MSG_CTL *pmctl, const TZCODE *p )
{
  GPS_CMD cmd = PZF_TZCODE | OPT_GPS_ACK_CODE;
  TZCODE *p_data = &pmctl->xmt.pmb->u.msg_data.tzcode;

  #if _USE_MUTEX
    _mbg_mutex_acquire( &pmctl->xmt.xmt_mutex );
  #endif

  *p_data = *p;
  //##++++++ _mbg_swab_tzcode( p_data );

  return mbgextio_xmt_msg( pmctl, cmd, NULL, sizeof( *p_data ) );

}  // mbgextio_get_tzdl


