
/**************************************************************************
 *
 *  $Id: lx-shared.h 1.2 2013/01/02 14:48:15 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    The definitions here could be shared with the standard
 *    Linux driver for Meinberg PCI cards.
 *
 * -----------------------------------------------------------------------
 *  $Log: lx-shared.h $
 *  Revision 1.2  2013/01/02 14:48:15  martin
 *  Cleanup.
 *  Revision 1.1  2011/01/25 11:28:26  martin
 *
 **************************************************************************/

#define DEBUG_SEM   ( defined( DEBUG ) && ( DEBUG >= DEBUG_LVL_SEM ) )

#if DEBUG_SEM


static __mbg_inline
void sprintf_pddev( char *s, const PCPS_DDEV *pddev )
{
  int n = 0;

  // This is always appended to an earlier msg.
  if ( pddev )
    n = sprintf( s, ", dev: %s_%s",
                 _pcps_ddev_type_name( pddev ),
                 _pcps_ddev_sernum( pddev )
               );

  s[n] = 0;

}  // sprintf_pddev



static __mbg_inline
void _sema_init_pddev( struct semaphore *ps, int n, const char *sem_name,
                       const char *fnc_name, const PCPS_DDEV *pddev )
{
  char ws[40];

  sprintf_pddev( ws, pddev );

  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %s initializing %s%s",
               pcps_driver_name, fnc_name, sem_name, ws );

  sema_init( ps, n );

}  // _sema_init_pddev



static __mbg_inline
int _down_interruptible_pddev( struct semaphore *ps, const char *sem_name,
                               const char *fnc_name, const PCPS_DDEV *pddev )
{
  int retval;
  char ws[40];

  sprintf_pddev( ws, pddev );

  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %s: going to get %s%s",
               pcps_driver_name, fnc_name, sem_name, ws );

  retval = down_interruptible( ps );

  if ( retval < 0 )
    _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %s: interrupted waiting for %s%s",
                 pcps_driver_name, fnc_name, sem_name, ws );
  else
    _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %s: got %s%s",
                 pcps_driver_name, fnc_name, sem_name, ws );

  return retval;

}  // _down_interruptible_pddev



static __mbg_inline
void _up_pddev( struct semaphore *ps, const char *sem_name,
                const char *fnc_name, const PCPS_DDEV *pddev )
{
  char ws[40];

  sprintf_pddev( ws, pddev );

  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %s: releasing %s%s",
               pcps_driver_name, fnc_name, sem_name, ws );

  up( ps );

}  // _up_pddev



static __mbg_inline
void _down( struct semaphore *ps, const char *sem_name,
            const char *fnc_name, void *p_id_struc )
{
  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: going to get %s",
               pcps_driver_name, p_id_struc, fnc_name, sem_name );

  down( ps );

  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: got %s",
               pcps_driver_name, p_id_struc, fnc_name, sem_name );
}  // _down



static __mbg_inline
int _down_interruptible( struct semaphore *ps, const char *sem_name,
                         const char *fnc_name, void *p_id_struc )
{
  int retval;

  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: going to get %s",
               pcps_driver_name, p_id_struc, fnc_name, sem_name );

  retval = down_interruptible( ps );

  if ( retval < 0 )
    _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: interrupted when waiting for %s",
                 pcps_driver_name, p_id_struc, fnc_name, sem_name );
  else
    _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: got %s",
                 pcps_driver_name, p_id_struc, fnc_name, sem_name );

  return retval;

}  // _down_interruptible



static __mbg_inline
int _down_trylock( struct semaphore *ps, const char *sem_name,
                   const char *fnc_name, void *p_id_struc )
{
  int retval;

  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: trying to get %s",
               pcps_driver_name, p_id_struc, fnc_name, sem_name );

  retval = down_trylock( ps );

  if ( retval < 0 )
    _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: failed to get %s",
                 pcps_driver_name, p_id_struc, fnc_name, sem_name );
  else
    _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: got %s",
                 pcps_driver_name, p_id_struc, fnc_name, sem_name );

  return retval;

}  // _down_trylock



static __mbg_inline
void _up( struct semaphore *ps, const char *sem_name,
          const char *fnc_name,  void *p_id_struc )
{
  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p %s: releasing %s",
               pcps_driver_name, p_id_struc, fnc_name, sem_name );

  up( ps );

}  // _up

#else

  #define _sema_init_pddev( _s, _n, _sn, _fn, _fp )       sema_init( _s, _n )
  #define _down_interruptible_pddev( _s, _sn, _fn, _fp )  down_interruptible( _s )
  #define _up_pddev( _s, _sn, _fn, _fp )                  up( _s )
  #define _down( _s, _sn, _fn, _fp )                      down( _s )
  #define _down_interruptible( _s, _sn, _fn, _fp )        down_interruptible( _s )
  #define _down_trylock( _s, _sn, _fn, _fp )              down_trylock( _s )
  #define _up( _s, _sn, _fn, _fp )                        up( _s )

#endif



static __mbg_inline
void set_dev_connected( PCPS_DDEV *pddev, int state )
{
  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: setting dev %s_%s connected state to %i",
               pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ),
               state );
  atomic_set( &pddev->connected, state );

}  // set_dev_connected



static __mbg_inline
int get_dev_connected( PCPS_DDEV *pddev )
{
  return atomic_read( &pddev->connected );

}  // get_dev_connected



static __mbg_inline /*HDR*/
int mbgdrvr_get_pddev( PCPS_DDEV **ppddev, struct file *filp, const char *info )
{
  PCPS_DDEV *pddev = NULL;
  int ret_val = 0;

  if ( _down_interruptible( &sem_fops, "sem_fops", info, filp ) < 0 )
  {
    ret_val = -ERESTARTSYS;
    goto out;
  }

  pddev = *( (PCPS_DDEV **) filp->private_data );

  if ( pddev == NULL )
  {
    _mbgddmsg_3( MBG_DBG_WARN, "%s: %p %s called with NULL device",
                 pcps_driver_name, filp, info );
    ret_val = -ENODEV;
    goto out_up_sem_fops;
  }

  if ( !get_dev_connected( pddev ) )
  {
    _mbgddmsg_5( MBG_DBG_WARN, "%s: %p %s called for disconnected dev %s_%s",
                 pcps_driver_name, filp, info, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    ret_val = -ENODEV;
    goto out_up_sem_fops;
  }

  _mbgddmsg_5( MBG_DBG_DETAIL, "%s: %p %s called, dev: %s_%s",
               pcps_driver_name, filp, info, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

out_up_sem_fops:
  _up( &sem_fops, "sem_fops", info, filp );

out:
  *ppddev = pddev;

  return ret_val;

}  // mbgdrvr_get_pddev



